
import { GoogleGenAI } from "@google/genai";

// Fixed: Using process.env.API_KEY directly for initialization as per SDK guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getReflectionSuggestion = async (question: string, context: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `你是一位充满智慧且富有同理心的心灵导师。
      针对用户在回答“${question}”时写下的内容：“${context}”，
      请给出一个简短、温暖且有深度的回应。
      要求：
      1. 肯定用户的付出或感受。
      2. 提供一个独特的视角或一句治愈的话。
      3. 使用中文，保持在 30 字以内。
      4. 不要使用说教的语气，要像老朋友一样交谈。`,
      config: {
        temperature: 0.8,
        maxOutputTokens: 100,
      }
    });
    // Fixed: accessing .text property directly (not as a function)
    return response.text?.trim() || "每一个微小的瞬间，都值得被温柔以待。";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "听起来是很重要的一刻，感谢你愿意记录下来。";
  }
};

export const summarizeDay = async (answers: { questionText: string, answer: string }[]) => {
  try {
    const context = answers.map(a => `${a.questionText}: ${a.answer}`).join('\n');
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `根据用户今日的复盘内容，总结成一句富有诗意且充满力量的中文短句（30字以内），作为今日的标题。内容如下：\n${context}`,
    });
    // Fixed: accessing .text property directly (not as a function)
    return response.text?.trim() || "每一天都是成长的足迹。";
  } catch (error) {
    return "充实的一天，继续加油。";
  }
};
