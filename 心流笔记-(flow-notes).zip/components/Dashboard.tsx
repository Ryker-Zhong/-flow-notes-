import React, { useState } from 'react';
import { Note, UserProfile, ThemeConfig, Reminder } from '../types';
import CustomCalendar from './CustomCalendar';

interface DashboardProps {
  notes: Note[];
  progress: number;
  onStartReflection: () => void;
  onProfileClick: () => void;
  userProfile?: UserProfile;
  theme: ThemeConfig;
  reminders: Reminder[];
  onToggleReminder: (id: number) => void;
  onRemoveReminder: (id: number) => void;
  onAddReminder: (text: string, date: Date, timeStr: string, category: string, isDaily: boolean) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
    onProfileClick, 
    userProfile, 
    theme, 
    reminders, 
    onToggleReminder, 
    onRemoveReminder, 
    onAddReminder 
}) => {
  const today = new Date().toLocaleDateString('zh-CN', { month: 'long', day: 'numeric', weekday: 'long' });
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newText, setNewText] = useState("");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedHour, setSelectedHour] = useState("12");
  const [selectedMinute, setSelectedMinute] = useState("00");
  const [newCategory, setNewCategory] = useState("工作");
  const [isDailyEssential, setIsDailyEssential] = useState(false);
  const [isDateModalOpen, setIsDateModalOpen] = useState(false);

  const categories = ["工作", "生活", "个人", "琐事"];
  const hours = Array.from({ length: 24 }, (_, i) => i.toString().padStart(2, '0'));
  const minutes = Array.from({ length: 60 }, (_, i) => i.toString().padStart(2, '0'));

  const handleAddReminder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;

    const timeStr = `${selectedHour}:${selectedMinute}`;
    onAddReminder(newText, selectedDate, timeStr, newCategory, isDailyEssential);

    setNewText("");
    setSelectedDate(new Date());
    setSelectedHour("12");
    setSelectedMinute("00");
    setNewCategory("工作");
    setIsDailyEssential(false);
    setIsModalOpen(false);
  };

  const removeReminder = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    onRemoveReminder(id);
  };

  const sortedReminders = [...reminders].sort((a, b) => {
    if (a.isDailyEssential && !b.isDailyEssential) return -1;
    if (!a.isDailyEssential && b.isDailyEssential) return 1;
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    if (a.dueTimestamp && b.dueTimestamp) return a.dueTimestamp - b.dueTimestamp;
    return 0;
  });

  return (
    <div className="h-full flex flex-col no-scrollbar overflow-y-auto fade-in bg-[#FFFDF9] relative">
      {/* Header */}
      <header className="px-6 pt-10 pb-4 flex justify-between items-center">
        <div>
          <p className="text-slate-400 text-sm font-medium">{today}</p>
          <h2 className="text-slate-900 text-3xl font-bold mt-1 tracking-tight font-display">
            晚上好, <span className="font-serif italic">{userProfile?.nickname || "Alex"}</span>
          </h2>
        </div>
        <button 
          onClick={onProfileClick}
          className={`size-12 overflow-hidden border-2 border-white shadow-sm ring-4 transition-transform active:scale-95 ${theme.colors.ringColor} ${userProfile?.avatarShape === 'stamp' ? 'rounded-[12px] border-dashed ' + theme.colors.border : 'rounded-full'}`}
        >
          <img 
            src={userProfile?.avatar || "https://picsum.photos/id/64/200/200"} 
            className="w-full h-full object-cover" 
            alt="Profile" 
          />
        </button>
      </header>

      {/* Weather Section */}
      <div className="px-6 py-4">
        <div className={`relative h-64 rounded-[2.5rem] overflow-hidden shadow-2xl border border-white group ${theme.colors.shadow}`}>
          <img 
            src="https://images.unsplash.com/photo-1534067783941-51c9c23ecefd?auto=format&fit=crop&w=800&q=80" 
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" 
            alt="Weather Background"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
          <div className="absolute top-6 left-6 flex items-center gap-2">
            <span className="material-symbols-outlined text-white/80 text-sm">location_on</span>
            <span className="text-white/80 text-xs font-bold uppercase tracking-widest">上海, 静安</span>
          </div>
          <div className="absolute bottom-8 left-8 text-white">
            <div className="flex items-center gap-4 mb-2">
              <span className="text-6xl font-bold">22°</span>
              <div className="h-10 w-px bg-white/30"></div>
              <div>
                <p className="text-xl font-bold font-display">多云转小雨</p>
                <p className="text-white/60 text-xs">空气质量: 优 (32)</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Reminders Section */}
      <div className="px-6 py-6 pb-32">
        <div className="flex justify-between items-center mb-6 px-1">
          <h3 className="text-slate-900 text-2xl font-bold tracking-tight font-display">今日提醒</h3>
          <span className={`text-xs font-bold px-2 py-1 rounded-lg ${theme.colors.secondaryBg} ${theme.colors.secondary}`}>
            {reminders.filter(r => !r.completed).length} 个待办
          </span>
        </div>
        <div className="space-y-4">
          {sortedReminders.map((reminder) => (
            <div 
              key={reminder.id}
              onClick={() => onToggleReminder(reminder.id)}
              className={`flex items-center gap-4 p-5 rounded-[1.8rem] border transition-all cursor-pointer animate-in fade-in slide-in-from-bottom-2 duration-300 group relative ${
                reminder.completed 
                  ? 'bg-slate-50 border-slate-100 opacity-60' 
                  : reminder.isDailyEssential 
                    ? 'bg-amber-50 border-amber-200 shadow-amber-100/40' 
                    : 'bg-white border-white shadow-sm hover:shadow-md hover:-translate-y-0.5 active:scale-[0.98]'
              }`}
            >
              <div className={`size-7 rounded-full border-2 flex items-center justify-center transition-all ${
                reminder.completed 
                  ? 'bg-emerald-400 border-emerald-400 text-white' 
                  : reminder.isDailyEssential 
                    ? 'border-amber-400 text-amber-400' 
                    : 'border-slate-200 text-transparent'
              }`}>
                <span className="material-symbols-outlined text-lg font-bold">
                  {reminder.isDailyEssential && !reminder.completed ? 'star' : 'check'}
                </span>
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-center">
                  <div className="flex flex-col">
                    <p className={`font-bold text-sm ${
                      reminder.completed ? 'text-slate-400 line-through' : reminder.isDailyEssential ? 'text-amber-900' : 'text-slate-800'
                    }`}>
                      {reminder.text}
                    </p>
                    {reminder.isDailyEssential && !reminder.completed && (
                      <span className="text-[9px] font-black text-amber-500 uppercase tracking-tighter mt-0.5">每日必办</span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                      reminder.completed 
                        ? 'bg-slate-100 text-slate-400' 
                        : reminder.isDailyEssential 
                          ? 'bg-amber-200/50 text-amber-700' 
                          : reminder.category === '工作' ? 'bg-indigo-50 text-indigo-400' : `${theme.colors.secondaryBg} ${theme.colors.secondary}`
                    }`}>
                      {reminder.time}
                    </span>
                    <button 
                      onClick={(e) => removeReminder(e, reminder.id)}
                      className={`size-8 flex items-center justify-center rounded-full transition-all opacity-0 group-hover:opacity-100 ${
                        reminder.isDailyEssential ? 'text-amber-400 hover:text-amber-600 hover:bg-amber-100' : `text-slate-300 hover:${theme.colors.primary} hover:${theme.colors.secondaryBg}`
                      }`}
                      title="取消提醒"
                    >
                      <span className="material-symbols-outlined text-lg">delete</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
          <button 
            onClick={() => setIsModalOpen(true)}
            className={`w-full py-5 rounded-[2rem] border-2 border-dashed border-slate-100 flex items-center justify-center gap-2 text-slate-300 hover:${theme.colors.secondary} hover:${theme.colors.border} hover:bg-white transition-all group`}
          >
            <span className="material-symbols-outlined group-hover:scale-125 transition-transform font-bold">add_circle</span>
            <span className="text-xs font-bold uppercase tracking-widest">添加新提醒</span>
          </button>
        </div>
      </div>

      {/* Modal with Daily Essential Switch */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-end justify-center px-4 pb-4 sm:items-center sm:p-0">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md transition-opacity" onClick={() => setIsModalOpen(false)}></div>
          <div className="relative transform overflow-hidden rounded-[2.8rem] bg-white text-left shadow-2xl transition-all w-full max-w-md animate-in slide-in-from-bottom duration-300">
            <form onSubmit={handleAddReminder} className="p-8 pt-10">
              <div className="flex justify-between items-center mb-8 px-2">
                <h3 className="text-2xl font-black text-slate-900 font-display tracking-tight">新建提醒事项</h3>
                <button type="button" onClick={() => setIsModalOpen(false)} className="size-10 flex items-center justify-center text-slate-300 hover:text-slate-500 bg-slate-50 hover:bg-slate-100 rounded-full transition-all">
                   <span className="material-symbols-outlined font-bold">close</span>
                </button>
              </div>

              <div className="space-y-7">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3 px-2">提醒内容</label>
                  <input 
                    type="text" autoFocus value={newText} onChange={(e) => setNewText(e.target.value)} placeholder="例如: 记得带伞，可能有雨..."
                    className={`w-full px-6 py-5 bg-slate-50 border-none rounded-[1.8rem] focus:ring-4 ${theme.colors.ring} transition-all text-slate-700 placeholder:text-slate-300 font-bold text-base`}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3 px-2">提醒日期</label>
                  <button
                      type="button"
                      onClick={() => setIsDateModalOpen(true)}
                      className={`w-full px-6 py-5 bg-slate-50 border-none rounded-[1.8rem] focus:ring-4 ${theme.colors.ring} transition-all text-slate-700 font-bold text-base text-left flex justify-between items-center`}
                  >
                      <span>{selectedDate.toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' })}</span>
                      <span className="material-symbols-outlined text-slate-400">calendar_month</span>
                  </button>
                </div>

                <div className="flex gap-4">
                  <div className="flex-1">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 px-2">执行时间</label>
                    <div className="flex gap-2 items-center bg-slate-50/50 p-2 rounded-[2rem]">
                      <div className="flex-1 group relative">
                        <select 
                          value={selectedHour} 
                          onChange={(e) => setSelectedHour(e.target.value)}
                          className={`w-full h-14 pl-4 pr-8 bg-white border-none rounded-[1.2rem] shadow-sm focus:ring-4 ${theme.colors.ring} appearance-none bg-none text-slate-700 font-black text-lg cursor-pointer transition-all`}
                        >
                          {hours.map(h => <option key={h} value={h}>{h}</option>)}
                        </select>
                        <span className="material-symbols-outlined absolute right-2 top-1/2 -translate-y-1/2 text-slate-300 pointer-events-none text-base">expand_more</span>
                      </div>
                      <span className="text-slate-200 text-xl font-black">:</span>
                      <div className="flex-1 group relative">
                        <select 
                          value={selectedMinute} 
                          onChange={(e) => setSelectedMinute(e.target.value)}
                          className={`w-full h-14 pl-4 pr-8 bg-white border-none rounded-[1.2rem] shadow-sm focus:ring-4 ${theme.colors.ring} appearance-none bg-none text-slate-700 font-black text-lg cursor-pointer transition-all`}
                        >
                          {minutes.map(m => <option key={m} value={m}>{m}</option>)}
                        </select>
                        <span className="material-symbols-outlined absolute right-2 top-1/2 -translate-y-1/2 text-slate-300 pointer-events-none text-base">expand_more</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="w-[120px]">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 px-2 text-center">每日必办</label>
                    <button 
                      type="button"
                      onClick={() => setIsDailyEssential(!isDailyEssential)}
                      className={`w-full h-14 rounded-[2rem] flex items-center justify-center transition-all ${
                        isDailyEssential ? 'bg-amber-100 text-amber-600 shadow-inner' : 'bg-slate-50 text-slate-300'
                      }`}
                    >
                      <span className={`material-symbols-outlined text-2xl font-bold transition-transform ${isDailyEssential ? 'scale-110 fill-1' : 'scale-90'}`}>
                        star
                      </span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 px-2">任务分类</label>
                  <div className="flex flex-wrap gap-2.5">
                    {categories.map(cat => (
                      <button
                        key={cat} 
                        type="button" 
                        onClick={() => setNewCategory(cat)}
                        className={`px-5 py-2.5 rounded-[1.2rem] text-xs font-black transition-all ${newCategory === cat ? `${theme.colors.primaryBg} text-white shadow-xl ${theme.colors.shadow} scale-105` : 'bg-slate-50 text-slate-400 border border-slate-100 hover:bg-slate-100 hover:text-slate-600'}`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Enlarged & Centered Button */}
                <div className="pt-6 pb-2 flex justify-center">
                  <button 
                    type="submit" 
                    disabled={!newText.trim()}
                    className="w-full sm:w-[90%] py-5 bg-slate-900 text-white rounded-[2rem] font-black text-lg hover:bg-slate-800 hover:-translate-y-1 active:scale-95 transition-all disabled:opacity-30 disabled:translate-y-0 disabled:scale-100 shadow-2xl shadow-slate-900/30 flex items-center justify-center gap-3"
                  >
                    <span className="material-symbols-outlined">
                      {isDailyEssential ? 'auto_awesome' : 'add_task'}
                    </span>
                    确认添加提醒
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
      {isDateModalOpen && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
              <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md transition-opacity" onClick={() => setIsDateModalOpen(false)}></div>
              <div className="relative z-10">
                  <CustomCalendar
                      value={selectedDate}
                      onChange={(date) => {
                          setSelectedDate(date);
                          setIsDateModalOpen(false);
                      }}
                      onClose={() => setIsDateModalOpen(false)}
                  />
              </div>
          </div>
      )}
    </div>
  );
};

export default Dashboard;