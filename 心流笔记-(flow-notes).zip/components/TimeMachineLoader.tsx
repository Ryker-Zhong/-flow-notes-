
import React from 'react';

const TimeMachineLoader: React.FC = () => {
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 cursor-wait">
      <style>{`
        @keyframes hourglass-spin {
          0% { transform: rotate(0deg); }
          25% { transform: rotate(180deg); }
          50% { transform: rotate(180deg); }
          75% { transform: rotate(360deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>

      {/* Soft Backdrop */}
      <div className="absolute inset-0 bg-indigo-950/20 backdrop-blur-sm animate-in fade-in duration-700"></div>

      {/* Main Animation Container */}
      <div className="relative flex flex-col items-center justify-center">
        
        {/* Spinner Group */}
        <div className="relative flex items-center justify-center">
          {/* Outer Ring */}
          <div className="absolute size-32 rounded-full border-2 border-indigo-200/30 border-t-indigo-500 animate-[spin_3s_linear_infinite]"></div>
          
          {/* Middle Ring (Reverse) */}
          <div className="absolute size-24 rounded-full border border-fuchsia-200/20 border-b-fuchsia-400 animate-[spin_2s_linear_infinite_reverse]"></div>

          {/* Center Core Container */}
          <div className="relative size-16 flex items-center justify-center">
               {/* Breathing Halo (Background Layer) */}
               <div className="absolute inset-0 bg-white/10 backdrop-blur-md rounded-full shadow-[0_0_40px_rgba(99,102,241,0.5)] animate-pulse"></div>
               
               {/* Hourglass Icon (Centered) */}
               <div className="relative z-10" style={{ animation: 'hourglass-spin 3s cubic-bezier(0.4, 0, 0.2, 1) infinite' }}>
                  <span className="block material-symbols-outlined text-4xl text-indigo-500">hourglass_top</span>
               </div>
          </div>
        </div>

        {/* Text - Adjusted margin-top to 110px to move text up */}
        <div className="mt-[110px] text-center space-y-1 animate-in slide-in-from-bottom-2 fade-in duration-1000">
          <p className="text-indigo-600 font-bold text-lg tracking-widest font-display">正在连接过去...</p>
          <p className="text-indigo-400/60 text-[10px] uppercase font-bold tracking-[0.3em]">Time Traveling</p>
        </div>
      </div>
    </div>
  );
};

export default TimeMachineLoader;
