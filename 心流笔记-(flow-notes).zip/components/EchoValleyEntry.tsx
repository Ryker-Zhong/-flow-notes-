
import React, { useState, useRef, useEffect } from 'react';
import { Note } from '../types';

interface EchoValleyEntryProps {
  onCancel: () => void;
  onSave: (note: Note) => void;
}

const EchoValleyEntry: React.FC<EchoValleyEntryProps> = ({ onCancel, onSave }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioData, setAudioData] = useState<string | null>(null);
  const [isReviewing, setIsReviewing] = useState(false);
  const [description, setDescription] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);
  const [transcript, setTranscript] = useState(""); 
  const [isSpeechSupported, setIsSpeechSupported] = useState(true);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // 检查浏览器是否支持 SpeechRecognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'zh-CN';

      recognition.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        
        // Update display with latest transcription
        const currentText = finalTranscript || interimTranscript;
        if (currentText) {
             // For continuous mode, we might want to just show the current result stream
             // or accumulate it. For simplicity, we just use the API's returned transcript structure
             const allText = Array.from(event.results)
                .map((result: any) => result[0].transcript)
                .join('');
             setTranscript(allText);
        }
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
      };

      recognitionRef.current = recognition;
    } else {
      setIsSpeechSupported(false);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (recognitionRef.current) recognitionRef.current.stop();
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = () => {
          const base64data = reader.result as string;
          setAudioData(base64data);
          // Autofill description with transcript
          if (transcript) {
              setDescription(transcript);
          }
          setIsReviewing(true);
        };
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorderRef.current.start();

      // Start Speech Recognition
      if (recognitionRef.current) {
        setTranscript(""); 
        try {
            recognitionRef.current.start();
        } catch (e) {
            console.error("Recognition start failed", e);
        }
      }

      setIsRecording(true);
      setRecordingTime(0);
      
      timerRef.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

    } catch (error) {
      console.error("Error accessing microphone:", error);
      alert("无法访问麦克风，请检查权限设置。");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      if (recognitionRef.current) {
          recognitionRef.current.stop();
      }
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  const togglePlayback = () => {
    if (!audioPlayerRef.current) return;
    
    if (isPlaying) {
      audioPlayerRef.current.pause();
    } else {
      audioPlayerRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleSave = () => {
    if (!audioData) return;

    const newNote: Note = {
      id: `ECHO-${Math.random().toString(36).substr(2, 9)}`,
      title: description ? (description.length > 10 ? description.substring(0, 10) + "..." : description) : "空谷回响",
      content: description || "一段来自过去的频率...",
      category: '空谷留音',
      type: 'ECHO',
      timestamp: new Date(),
      audioData: audioData,
      duration: recordingTime
    };
    onSave(newNote);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="h-full flex flex-col fade-in bg-gradient-to-b from-teal-50 to-[#F0FDFA] relative overflow-hidden">
      {/* Visualizer Background Animation */}
      <div className="absolute inset-0 z-0 flex items-center justify-center pointer-events-none opacity-20">
         <div className={`flex items-center gap-2 ${isRecording ? 'animate-pulse' : ''}`}>
             {[...Array(8)].map((_, i) => (
                 <div 
                    key={i} 
                    className="w-4 bg-teal-400 rounded-full transition-all duration-300"
                    style={{ 
                        height: isRecording ? `${Math.random() * 100 + 50}px` : '40px',
                        animation: isRecording ? `bounce ${0.5 + Math.random() * 0.5}s infinite` : 'none'
                    }}
                 ></div>
             ))}
         </div>
      </div>

      <header className="flex-none px-6 pt-10 pb-4 flex items-center justify-between relative z-10">
        <button onClick={onCancel} className="size-10 flex items-center justify-center bg-white/80 rounded-full shadow-sm text-teal-700 backdrop-blur-md">
          <span className="material-symbols-outlined">close</span>
        </button>
        <div className="flex flex-col items-center">
            <h2 className="text-teal-900 text-lg font-bold">空谷留音</h2>
            <p className="text-[10px] text-teal-500 font-bold uppercase tracking-widest">Echo in the Valley</p>
        </div>
        <div className="w-10"></div>
      </header>

      <main className="flex-1 px-8 flex flex-col items-center justify-center relative z-10">
        {!isReviewing ? (
          <>
            <div className="mb-8 relative shrink-0">
                <div className={`absolute inset-0 bg-teal-300 rounded-full blur-3xl opacity-20 transition-all duration-500 ${isRecording ? 'scale-150 opacity-40' : 'scale-100'}`}></div>
                <button 
                  onClick={isRecording ? stopRecording : startRecording}
                  className={`relative size-32 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 ${
                      isRecording 
                      ? 'bg-red-500 text-white scale-110 ring-8 ring-red-100' 
                      : 'bg-teal-500 text-white hover:bg-teal-600 ring-8 ring-teal-100'
                  }`}
                >
                  <span className={`material-symbols-outlined text-5xl ${isRecording ? 'animate-pulse' : ''}`}>
                      {isRecording ? 'stop' : 'mic'}
                  </span>
                </button>
            </div>
            
            <div className="text-center space-y-2 mb-8 shrink-0">
                <p className="text-4xl font-black text-teal-900 font-display tracking-tight">
                    {formatTime(recordingTime)}
                </p>
                <div className="flex items-center justify-center gap-2">
                    {isRecording && <span className="size-2 bg-red-500 rounded-full animate-pulse"></span>}
                    <p className="text-teal-600 text-sm font-medium">
                        {isRecording ? "正在聆听并转录..." : "点击录制当下的声音"}
                    </p>
                </div>
            </div>

            {/* Real-time Transcript Display */}
            <div className={`w-full max-w-xs min-h-[120px] max-h-[200px] overflow-y-auto bg-white/40 backdrop-blur-sm rounded-2xl p-4 border border-white/50 transition-all duration-500 ${isRecording || transcript ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
                {transcript ? (
                    <p className="text-teal-800 text-lg font-medium leading-relaxed text-center animate-in fade-in">
                        "{transcript}"
                    </p>
                ) : (
                    <p className="text-teal-800/30 text-sm text-center italic">
                        {isRecording ? "试着说点什么..." : ""}
                    </p>
                )}
            </div>
          </>
        ) : (
          <div className="w-full max-w-xs animate-in zoom-in-95 duration-500">
             <div className="bg-white/60 backdrop-blur-lg rounded-[2.5rem] p-8 shadow-xl border border-white mb-8">
                <div className="flex items-center justify-center mb-6">
                    <button 
                        onClick={togglePlayback}
                        className="size-20 bg-teal-500 text-white rounded-full flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition-all"
                    >
                        <span className="material-symbols-outlined text-4xl fill-1 ml-1">
                            {isPlaying ? 'pause' : 'play_arrow'}
                        </span>
                    </button>
                </div>
                {/* Hidden Audio Element */}
                {audioData && (
                    <audio 
                        ref={audioPlayerRef} 
                        src={audioData} 
                        onEnded={() => setIsPlaying(false)} 
                    />
                )}
                
                <div className="text-center mb-6">
                    <p className="text-teal-900 font-bold text-lg">录音完成</p>
                    <p className="text-teal-500 text-xs font-bold uppercase tracking-widest mt-1">时长 {formatTime(recordingTime)}</p>
                </div>

                <div className="relative">
                    <textarea 
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="添加一段文字描述..."
                      className="w-full h-24 bg-white/50 border-none rounded-xl text-center text-teal-800 placeholder:text-teal-300/70 focus:ring-2 focus:ring-teal-200 py-3 px-4 text-sm font-medium resize-none"
                    />
                    {description && (
                        <div className="absolute right-2 bottom-2">
                             <span className="text-[10px] text-teal-400 bg-teal-50 px-2 py-1 rounded-full">已自动转录</span>
                        </div>
                    )}
                </div>
             </div>

             <div className="flex gap-4">
                 <button 
                    onClick={() => {
                        setIsReviewing(false);
                        setAudioData(null);
                        setRecordingTime(0);
                        setTranscript("");
                    }}
                    className="flex-1 py-4 bg-white text-teal-600 rounded-2xl font-bold shadow-sm hover:bg-teal-50 transition-colors"
                 >
                    重录
                 </button>
                 <button 
                    onClick={handleSave}
                    className="flex-1 py-4 bg-teal-600 text-white rounded-2xl font-bold shadow-lg shadow-teal-600/20 hover:bg-teal-700 transition-colors"
                 >
                    保存
                 </button>
             </div>
          </div>
        )}
      </main>

      {!isReviewing && (
        <div className="p-8 text-center relative z-10 shrink-0">
            <p className="text-teal-800/60 text-xs leading-relaxed max-w-[200px] mx-auto">
                {isSpeechSupported ? "有些人，有些事，只有声音能带你回到那个瞬间。" : "当前浏览器暂不支持实时语音转文字，但仍可录音。"}
            </p>
        </div>
      )}
    </div>
  );
};

export default EchoValleyEntry;
