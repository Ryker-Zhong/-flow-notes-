import React from 'react';
import { AppView, ThemeConfig } from '../types';

interface BottomNavProps {
  activeView: AppView;
  onViewChange: (view: AppView) => void;
  onAddClick: () => void;
  theme: ThemeConfig;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeView, onViewChange, onAddClick, theme }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 max-w-md mx-auto bg-white/80 backdrop-blur-xl border-t border-white/40 pb-6 pt-2 px-6">
      <ul className="flex items-center justify-between">
        <li className="flex-1">
          <button 
            onClick={() => onViewChange(AppView.DASHBOARD)}
            className={`w-full flex flex-col items-center gap-1 transition-colors ${activeView === AppView.DASHBOARD ? theme.colors.primary : 'text-slate-400'}`}
          >
            <span className={`material-symbols-outlined text-[26px] ${activeView === AppView.DASHBOARD ? 'fill-1' : ''}`}>home</span>
            <span className="text-[10px] font-bold">首页</span>
          </button>
        </li>
        <li className="flex-1">
          <button 
            onClick={() => onViewChange(AppView.DIARY)}
            className={`w-full flex flex-col items-center gap-1 transition-colors ${activeView === AppView.DIARY ? theme.colors.primary : 'text-slate-400'}`}
          >
            <span className={`material-symbols-outlined text-[26px] ${activeView === AppView.DIARY ? 'fill-1' : ''}`}>auto_stories</span>
            <span className="text-[10px] font-bold">日记</span>
          </button>
        </li>
        <li className="relative -top-5 px-4">
          <button 
            onClick={onAddClick}
            className="flex items-center justify-center size-14 bg-slate-900 text-white rounded-full shadow-2xl shadow-slate-900/20 active:scale-90 transition-transform hover:scale-105"
          >
            <span className="material-symbols-outlined text-3xl">add</span>
          </button>
        </li>
        <li className="flex-1">
          <button 
            onClick={() => onViewChange(AppView.REVIEW)}
            className={`w-full flex flex-col items-center gap-1 transition-colors ${activeView === AppView.REVIEW ? theme.colors.primary : 'text-slate-400'}`}
          >
            <span className={`material-symbols-outlined text-[26px] ${activeView === AppView.REVIEW ? 'fill-1' : ''}`}>auto_awesome</span>
            <span className="text-[10px] font-bold">回顾</span>
          </button>
        </li>
        <li className="flex-1">
          <button 
            onClick={() => onViewChange(AppView.SETTINGS)}
            className={`w-full flex flex-col items-center gap-1 transition-colors ${activeView === AppView.SETTINGS ? theme.colors.primary : 'text-slate-400'}`}
          >
            <span className={`material-symbols-outlined text-[26px] ${activeView === AppView.SETTINGS ? 'fill-1' : ''}`}>person</span>
            <span className="text-[10px] font-bold">我的</span>
          </button>
        </li>
      </ul>
    </nav>
  );
};

export default BottomNav;