import React, { useState, useRef } from 'react';
import { Note, ThemeConfig } from '../types';

interface DiaryViewProps {
  notes: Note[];
  theme: ThemeConfig;
}

const DiaryView: React.FC<DiaryViewProps> = ({ notes, theme }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("全部");
  const [activeTimeRange, setActiveTimeRange] = useState<string>("全部时间");
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  
  const audioRefs = useRef<{ [key: string]: HTMLAudioElement | null }>({});

  const categories = ["全部", "工作", "生活", "灵感", "个人", "时空信笺", "空谷留音"];
  const timeRanges = ["全部时间", "今天", "本周", "本月"];

  const isWithinTimeRange = (date: Date, range: string) => {
    const now = new Date();
    const noteDate = new Date(date);
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    switch (range) {
      case "今天":
        return noteDate >= startOfToday;
      case "本周":
        const startOfWeek = new Date(now);
        startOfWeek.setDate(now.getDate() - 7);
        return noteDate >= startOfWeek;
      case "本月":
        const startOfMonth = new Date(now);
        startOfMonth.setMonth(now.getMonth() - 1);
        return noteDate >= startOfMonth;
      default:
        return true;
    }
  };

  const filteredNotes = notes.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          note.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === "全部" || note.category === activeCategory;
    const matchesTime = isWithinTimeRange(note.timestamp, activeTimeRange);
    
    return matchesSearch && matchesCategory && matchesTime;
  });

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric', weekday: 'short' });
  };

  const isLocked = (note: Note) => {
    if (note.type !== 'FUTURE_LETTER' || !note.unlockDate) return false;
    return new Date() < new Date(note.unlockDate);
  };

  const toggleListAudio = (e: React.MouseEvent, note: Note) => {
    e.stopPropagation();
    const audio = audioRefs.current[note.id];
    if (!audio) return;

    if (playingAudioId === note.id) {
      audio.pause();
      setPlayingAudioId(null);
    } else {
      if (playingAudioId && audioRefs.current[playingAudioId]) {
        audioRefs.current[playingAudioId]?.pause();
      }
      audio.play();
      setPlayingAudioId(note.id);
    }
  };

  return (
    <div className="h-full flex flex-col no-scrollbar overflow-y-auto fade-in bg-gradient-to-b from-[#FFFDF9] to-[#FAF0E6] relative">
      <header className="px-6 pt-12 pb-6 text-center">
        <h2 className="text-slate-900 text-3xl font-bold tracking-tight">我的足迹</h2>
        <p className="text-slate-400 text-sm mt-1">
          {filteredNotes.length === notes.length 
            ? `共记录了 ${notes.length} 个瞬间` 
            : `筛选出 ${filteredNotes.length} 篇记录`}
        </p>
      </header>

      <div className="px-6 space-y-5 mb-8">
        <div className="relative group">
          <span className={`material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:${theme.colors.secondary} transition-colors`}>search</span>
          <input 
            type="text"
            placeholder="寻找记忆碎片..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full pl-12 pr-4 py-4 bg-white border-none rounded-2xl shadow-sm focus:ring-4 ${theme.colors.ring} text-slate-700 placeholder:text-slate-300 transition-all font-medium`}
          />
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
            <span className="material-symbols-outlined text-slate-300 text-sm flex-none">schedule</span>
            {timeRanges.map(range => (
              <button
                key={range}
                onClick={() => setActiveTimeRange(range)}
                className={`px-4 py-2 rounded-xl text-[11px] font-black whitespace-nowrap transition-all border ${
                  activeTimeRange === range 
                  ? 'bg-amber-100 border-amber-200 text-amber-700 shadow-sm' 
                  : 'bg-white/60 border-transparent text-slate-400 hover:bg-white hover:text-slate-600'
                }`}
              >
                {range}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2 py-1">
             <span className="material-symbols-outlined text-slate-300 text-sm flex-none mr-1">sell</span>
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-xl text-[11px] font-black whitespace-nowrap transition-all border ${
                  activeCategory === cat 
                  ? 'bg-slate-900 border-slate-900 text-white shadow-lg' 
                  : 'bg-white/60 border-transparent text-slate-400 hover:bg-white hover:text-slate-600'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="px-6 pb-32 space-y-4">
        {filteredNotes.length > 0 ? (
          filteredNotes.map((note) => {
            const locked = isLocked(note);
            const isEcho = note.type === 'ECHO';

            return (
              <div 
                key={note.id}
                onClick={() => !locked && setSelectedNote(note)}
                className={`bg-white/80 backdrop-blur-sm rounded-[2rem] p-6 shadow-sm border border-white hover:shadow-md transition-all active:scale-[0.98] group cursor-pointer ${locked ? 'opacity-90' : ''}`}
              >
                <div className="flex justify-between items-start mb-4">
                  <div className="flex flex-col flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">
                        {formatDate(note.timestamp)}
                      </span>
                      <span className="size-1 rounded-full bg-slate-200"></span>
                      <span className={`text-[9px] font-black px-2 py-0.5 rounded-md ${
                        note.category === '工作' ? 'bg-indigo-50 text-indigo-500' :
                        note.category === '生活' ? 'bg-emerald-50 text-emerald-500' :
                        note.category === '时空信笺' ? 'bg-orange-100 text-orange-600' :
                        note.category === '空谷留音' ? 'bg-teal-50 text-teal-600' :
                        `${theme.colors.secondaryBg} ${theme.colors.primary}`
                      }`}>
                        {note.category}
                      </span>
                    </div>
                    <h4 className={`text-lg font-bold group-hover:${theme.colors.primary} transition-colors leading-snug ${locked ? 'text-orange-300' : 'text-slate-900'}`}>
                      {locked ? "封存中的信笺" : note.title}
                    </h4>
                  </div>
                  {locked ? (
                    <div className="size-10 bg-orange-50 rounded-full flex items-center justify-center text-orange-400">
                       <span className="material-symbols-outlined fill-1">history</span>
                    </div>
                  ) : isEcho ? (
                    <button 
                       onClick={(e) => toggleListAudio(e, note)}
                       className={`size-10 rounded-full flex items-center justify-center transition-all ${
                          playingAudioId === note.id 
                          ? 'bg-teal-500 text-white shadow-lg scale-110' 
                          : 'bg-teal-50 text-teal-500 hover:bg-teal-100'
                       }`}
                    >
                       <span className="material-symbols-outlined fill-1">
                          {playingAudioId === note.id ? 'pause' : 'play_arrow'}
                       </span>
                       {note.audioData && (
                          <audio 
                             ref={el => { audioRefs.current[note.id] = el; }}
                             src={note.audioData}
                             onEnded={() => setPlayingAudioId(null)}
                          />
                       )}
                    </button>
                  ) : null}
                </div>
                
                {locked ? (
                  <div className="py-4 bg-orange-50/30 rounded-2xl flex flex-col items-center gap-2 border border-orange-100/50">
                    <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest">距离开启还有</span>
                    <span className="text-xl font-black text-orange-600 font-display">
                      {Math.ceil((new Date(note.unlockDate!).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} 天
                    </span>
                    <span className="text-[9px] text-orange-300 font-medium">将于 {formatDate(note.unlockDate!)} 解锁</span>
                  </div>
                ) : isEcho ? (
                  <div className="flex items-center gap-3 p-3 bg-teal-50/50 rounded-2xl border border-teal-100/50">
                     <div className="flex-1 h-8 flex items-center gap-1 overflow-hidden px-2">
                        {[...Array(20)].map((_, i) => (
                           <div 
                              key={i} 
                              className={`w-1 rounded-full bg-teal-300/50 ${playingAudioId === note.id ? 'animate-pulse' : ''}`}
                              style={{ height: Math.random() * 20 + 4 + 'px' }}
                           ></div>
                        ))}
                     </div>
                     <span className="text-[10px] font-bold text-teal-400 whitespace-nowrap px-2">
                       {note.duration ? `${Math.floor(note.duration/60)}:${(note.duration%60).toString().padStart(2,'0')}` : 'Voice'}
                     </span>
                  </div>
                ) : (
                  <p className="text-slate-500 text-sm line-clamp-3 leading-relaxed mb-4">
                    {note.content}
                  </p>
                )}
                
                {!locked && (
                  <div className="pt-4 border-t border-slate-50 flex justify-between items-center mt-2">
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <span className="material-symbols-outlined text-sm">sticky_note_2</span>
                      <span className="text-[10px] font-bold uppercase tracking-widest">查看详情</span>
                    </div>
                    <span className="material-symbols-outlined text-slate-200 text-lg group-hover:translate-x-1 transition-transform">arrow_forward_ios</span>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="py-20 text-center flex flex-col items-center">
            <div className="size-24 bg-white/50 rounded-full flex items-center justify-center mb-6 shadow-inner border border-white">
              <span className="material-symbols-outlined text-slate-200 text-5xl">manage_search</span>
            </div>
            <p className="text-slate-400 font-bold text-lg">没有找到匹配的记录</p>
          </div>
        )}
      </div>

      {/* Note Detail Modal - Updated Theme logic if needed */}
      {selectedNote && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-xl" onClick={() => setSelectedNote(null)}></div>
          <div className="bg-white w-full max-w-sm rounded-[3rem] shadow-2xl relative z-10 overflow-hidden flex flex-col animate-in zoom-in-95 slide-in-from-bottom-10 duration-500">
            <div className={`h-24 w-full relative overflow-hidden flex items-end px-8 pb-4 ${
                selectedNote.category === '工作' ? 'bg-indigo-500' :
                selectedNote.category === '生活' ? 'bg-emerald-500' :
                selectedNote.category === '时空信笺' ? 'bg-orange-400' :
                selectedNote.category === '空谷留音' ? 'bg-teal-500' :
                theme.colors.primaryBg
              }`}>
              <div className="absolute top-0 right-0 p-4 opacity-20">
                <span className="material-symbols-outlined text-6xl text-white">
                  {selectedNote.category === '时空信笺' ? 'history' : selectedNote.category === '空谷留音' ? 'graphic_eq' : 'auto_stories'}
                </span>
              </div>
              <button 
                onClick={() => setSelectedNote(null)}
                className="absolute top-4 right-4 size-10 flex items-center justify-center bg-black/10 hover:bg-black/20 text-white rounded-full transition-all"
              >
                <span className="material-symbols-outlined font-bold">close</span>
              </button>
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-white/20 backdrop-blur-md rounded-lg text-[10px] font-black text-white uppercase tracking-widest">
                  {selectedNote.category}
                </span>
                <span className="text-white/80 text-[10px] font-bold">
                  {formatDate(selectedNote.timestamp)}
                </span>
              </div>
            </div>

            <div className="p-8 flex-1 overflow-y-auto no-scrollbar">
              <h3 className="text-2xl font-black text-slate-900 leading-tight mb-6">
                {selectedNote.title}
              </h3>
              
              {selectedNote.type === 'ECHO' && selectedNote.audioData ? (
                 <div className="mb-8 p-6 bg-teal-50 rounded-3xl flex flex-col items-center gap-4">
                     <audio controls src={selectedNote.audioData} className="w-full h-10 accent-teal-500" />
                     <p className="text-xs text-teal-400 font-bold uppercase tracking-widest">Recording from {formatDate(selectedNote.timestamp)}</p>
                 </div>
              ) : (
                <div className="h-1 w-12 bg-slate-100 rounded-full mb-6"></div>
              )}

              <p className={`text-slate-600 text-lg leading-relaxed whitespace-pre-wrap ${selectedNote.category === '时空信笺' ? 'font-serif italic' : ''}`}>
                {selectedNote.content}
              </p>
            </div>

            <div className="p-6 bg-slate-50/50 border-t border-slate-100 flex justify-center">
              <button 
                onClick={() => setSelectedNote(null)}
                className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-slate-900/10 active:scale-95 transition-all"
              >
                关闭阅读
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DiaryView;