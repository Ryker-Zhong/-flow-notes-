import React, { useState } from 'react';
import { Note, ThemeConfig } from '../types';

interface InspirationEntryProps {
  onCancel: () => void;
  onSave: (note: Note) => void;
  theme: ThemeConfig;
}

const InspirationEntry: React.FC<InspirationEntryProps> = ({ onCancel, onSave, theme }) => {
  const [content, setContent] = useState("");

  const handleSave = () => {
    if (!content.trim()) return;
    
    // Auto-generate a title from the first part of the content
    const autoTitle = content.trim().split('\n')[0].substring(0, 20) || "灵感碎片";

    const newNote: Note = {
      id: `INSP-${Date.now()}`,
      title: `灵感：${autoTitle}`,
      content,
      category: '灵感',
      type: 'DIARY', // It's a text-based note
      timestamp: new Date()
    };
    onSave(newNote);
  };

  return (
    <div className="h-full flex flex-col fade-in bg-gradient-to-br from-amber-50 via-[#FFFDF9] to-amber-50/50">
      <header className="flex-none px-6 pt-10 pb-4 flex items-center justify-between">
        <button onClick={onCancel} className="size-10 flex items-center justify-center bg-white rounded-full shadow-sm text-slate-400">
          <span className="material-symbols-outlined">close</span>
        </button>
        <h2 className="text-amber-900 text-lg font-bold tracking-widest">灵感小集</h2>
        <div className="w-10"></div>
      </header>

      <main className="flex-1 px-8 pt-8 flex flex-col gap-6 relative">
        <div className="absolute top-8 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-10 pointer-events-none">
            <span className="material-symbols-outlined text-9xl text-amber-400">lightbulb</span>
        </div>
        <textarea 
          autoFocus
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="捕捉一闪而过的念头..."
          className="w-full h-full text-2xl leading-relaxed text-amber-900/80 border-none bg-transparent p-0 focus:ring-0 placeholder:text-amber-300 resize-none no-scrollbar text-center"
        />
      </main>

      <div className="flex-none p-8">
        <button 
          onClick={handleSave}
          disabled={!content.trim()}
          className="w-full h-16 bg-amber-500 hover:bg-amber-600 disabled:opacity-20 text-white font-black text-sm uppercase tracking-[0.2em] rounded-2xl shadow-2xl shadow-amber-500/20 flex items-center justify-center gap-3 active:scale-[0.98] transition-all"
        >
          捕捉这个想法
          <span className="material-symbols-outlined">auto_awesome</span>
        </button>
      </div>
    </div>
  );
};

export default InspirationEntry;