
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Note } from '../types';

interface FutureLetterEntryProps {
  onCancel: () => void;
  onSave: (note: Note) => void;
}

interface TimePreset {
  label: string;
  calc: () => Date;
}

const FutureLetterEntry: React.FC<FutureLetterEntryProps> = ({ onCancel, onSave }) => {
  const [content, setContent] = useState("");
  const [title, setTitle] = useState("致未来的自己");
  const [isAnimating, setIsAnimating] = useState(false);
  const rollerRef = useRef<HTMLDivElement>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const [activeIndex, setActiveIndex] = useState(3); // 默认 1年后

  const ITEM_WIDTH = 110; // 统一定义项宽度以保证计算精准

  const presets: TimePreset[] = useMemo(() => [
    { label: '1个月', calc: () => { const d = new Date(); d.setMonth(d.getMonth() + 1); return d; } },
    { label: '3个月', calc: () => { const d = new Date(); d.setMonth(d.getMonth() + 3); return d; } },
    { label: '半年后', calc: () => { const d = new Date(); d.setMonth(d.getMonth() + 6); return d; } },
    { label: '1年后', calc: () => { const d = new Date(); d.setFullYear(d.getFullYear() + 1); return d; } },
    { label: '3年后', calc: () => { const d = new Date(); d.setFullYear(d.getFullYear() + 3); return d; } },
    { label: '5年后', calc: () => { const d = new Date(); d.setFullYear(d.getFullYear() + 5); return d; } },
    { label: '10年后', calc: () => { const d = new Date(); d.setFullYear(d.getFullYear() + 10); return d; } },
    { label: '20年后', calc: () => { const d = new Date(); d.setFullYear(d.getFullYear() + 20); return d; } },
  ], []);

  const unlockDate = useMemo(() => {
    return presets[activeIndex].calc();
  }, [activeIndex, presets]);

  const daysDiff = useMemo(() => {
    const start = new Date();
    const end = unlockDate;
    const diffTime = Math.abs(end.getTime() - start.getTime());
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }, [unlockDate]);

  const playSound = (type: 'slide' | 'fold' | 'stamp' | 'fly') => {
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') ctx.resume();
      const now = ctx.currentTime;

      if (type === 'slide') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.setValueAtTime(400, now);
        osc.frequency.exponentialRampToValueAtTime(800, now + 2.0);
        gain.gain.setValueAtTime(0.03, now);
        gain.gain.linearRampToValueAtTime(0, now + 2.0);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(now + 2.0);
      } else if (type === 'fold') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(150, now);
        osc.frequency.linearRampToValueAtTime(80, now + 0.8);
        gain.gain.setValueAtTime(0.04, now);
        gain.gain.linearRampToValueAtTime(0, now + 0.8);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(now + 0.8);
      } else if (type === 'stamp') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.exponentialRampToValueAtTime(440, now + 0.8);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(now + 0.8);
      } else if (type === 'fly') {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(200, now);
        osc.frequency.exponentialRampToValueAtTime(1500, now + 4.0);
        gain.gain.setValueAtTime(0.03, now);
        gain.gain.linearRampToValueAtTime(0, now + 4.0);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(now + 4.0);
      }
    } catch (e) {
      console.warn("Audio Context error:", e);
    }
  };

  const handleSave = () => {
    if (!content.trim()) return;
    setIsAnimating(true);

    setTimeout(() => playSound('slide'), 500);
    setTimeout(() => playSound('fold'), 2500);
    setTimeout(() => playSound('stamp'), 4000);
    setTimeout(() => playSound('fly'), 6000);

    setTimeout(() => {
      const newNote: Note = {
        id: `FL-${Math.random().toString(36).substr(2, 9)}`,
        title: title || "无题信笺",
        content,
        category: '时空信笺',
        type: 'FUTURE_LETTER',
        timestamp: new Date(),
        unlockDate: unlockDate
      };
      onSave(newNote);
    }, 10000);
  };

  const handleScroll = () => {
    if (!rollerRef.current) return;
    const scrollLeft = rollerRef.current.scrollLeft;
    const newIndex = Math.round(scrollLeft / ITEM_WIDTH);
    if (newIndex >= 0 && newIndex < presets.length && newIndex !== activeIndex) {
      setActiveIndex(newIndex);
    }
  };

  useEffect(() => {
    if (rollerRef.current) {
      rollerRef.current.scrollLeft = activeIndex * ITEM_WIDTH;
    }
  }, []);

  return (
    <div className="h-full flex flex-col fade-in bg-[#FFFAF5] relative overflow-hidden">
      <style>{`
        @keyframes letter-slide-in {
          0% { transform: translateY(-130%) scale(0.92); opacity: 0; }
          30% { transform: translateY(-110%) scale(1); opacity: 1; }
          100% { transform: translateY(18%); opacity: 1; }
        }
        @keyframes flap-fold-down {
          0% { transform: perspective(1200px) rotateX(-180deg); }
          100% { transform: perspective(1200px) rotateX(0deg); }
        }
        @keyframes seal-impact {
          0% { transform: translate(-50%, -50%) scale(6); opacity: 0; filter: blur(12px); }
          70% { transform: translate(-50%, -50%) scale(0.8); opacity: 1; filter: blur(0); }
          100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
        }
        @keyframes final-journey {
          0% { transform: translateY(0) scale(1) rotate(0); filter: blur(0); }
          15% { transform: translateY(20px) scale(1.05) rotate(-1deg); }
          100% { transform: translateY(-2500px) scale(0.1) rotate(25deg); opacity: 0; filter: blur(20px); }
        }
        @keyframes background-breathing {
          0%, 100% { background-color: rgba(255, 255, 255, 1); }
          50% { background-color: rgba(255, 248, 241, 1); }
        }
        @keyframes sparkle-float {
          0%, 100% { transform: translate(0, 0) scale(1); opacity: 0.2; }
          50% { transform: translate(10px, -15px) scale(1.3); opacity: 0.8; }
        }
        @keyframes border-glow {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }

        .animate-letter-slide { animation: letter-slide-in 2.0s cubic-bezier(0.45, 0, 0.55, 1) forwards 0.5s; }
        .animate-flap-fold { animation: flap-fold-down 1.5s cubic-bezier(0.34, 1.56, 0.64, 1) forwards 2.5s; transform-origin: top; }
        .animate-seal-hit { animation: seal-impact 1.0s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards 4.0s; opacity: 0; }
        .animate-envelope-launch { animation: final-journey 4.0s cubic-bezier(0.65, 0, 0.35, 1) forwards 6.0s; }
        .envelope-perspective { perspective: 1200px; }
      `}</style>

      {isAnimating && (
        <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center animate-[background-breathing_6s_infinite]">
          {/* 背景漂浮物 */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {[...Array(15)].map((_, i) => (
              <div 
                key={i} 
                className="absolute bg-orange-100/30 rounded-full blur-3xl animate-pulse"
                style={{
                  width: Math.random() * 300 + 100 + 'px',
                  height: Math.random() * 300 + 100 + 'px',
                  top: Math.random() * 100 + '%',
                  left: Math.random() * 100 + '%',
                  animationDelay: Math.random() * 4 + 's'
                }}
              />
            ))}
          </div>

          <div className="relative w-80 h-52 animate-envelope-launch envelope-perspective">
            {/* 信封主体 */}
            <div className="absolute inset-0 bg-[#FFF3E5] rounded-xl shadow-2xl border border-orange-200/40 z-10 overflow-hidden">
               {/* 金色装饰护角 */}
               <div className="absolute top-0 left-0 size-8 border-t-2 border-l-2 border-amber-400/30 rounded-tl-xl opacity-60"></div>
               <div className="absolute top-0 right-0 size-8 border-t-2 border-r-2 border-amber-400/30 rounded-tr-xl opacity-60"></div>
               <div className="absolute bottom-0 left-0 size-8 border-b-2 border-l-2 border-amber-400/30 rounded-bl-xl opacity-60"></div>
               <div className="absolute bottom-0 right-0 size-8 border-b-2 border-r-2 border-amber-400/30 rounded-br-xl opacity-60"></div>
               
               {/* 淡淡的波纹底纹 */}
               <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#C2410C 1px, transparent 0)', backgroundSize: '20px 20px' }}></div>
            </div>

            {/* 信纸 */}
            <div className="absolute top-0 left-6 right-6 h-44 bg-white rounded-md shadow-md z-20 animate-letter-slide p-6 flex flex-col border border-orange-50/50">
              <div className="w-1/2 h-2.5 bg-orange-50 rounded-full mb-6"></div>
              <div className="space-y-3">
                <div className="w-full h-1.5 bg-slate-50 rounded-full"></div>
                <div className="w-full h-1.5 bg-slate-50 rounded-full"></div>
                <div className="w-4/5 h-1.5 bg-slate-50 rounded-full"></div>
                <div className="w-full h-1.5 bg-slate-50 rounded-full"></div>
                <div className="w-2/3 h-1.5 bg-slate-50 rounded-full"></div>
              </div>
              <div className="mt-auto self-end flex items-center gap-2 opacity-30">
                <span className="text-[10px] font-serif">Sincerely, Me</span>
                <span className="material-symbols-outlined text-orange-400">signature</span>
              </div>
            </div>

            {/* 信封折叠页 */}
            <div className="absolute inset-0 z-30 pointer-events-none">
              <div className="absolute inset-0 bg-[#FFFAF5] shadow-sm" 
                   style={{clipPath: 'polygon(0 0, 50% 50%, 0 100%)', borderLeft: '1px solid #FFF'}} ></div>
              <div className="absolute inset-0 bg-[#FFFAF5] shadow-sm" 
                   style={{clipPath: 'polygon(100% 0, 50% 50%, 100% 100%)', borderRight: '1px solid #FFF'}} ></div>
              <div className="absolute inset-0 bg-gradient-to-t from-[#FFF3E8] to-[#FFFBF5] shadow-sm" 
                   style={{clipPath: 'polygon(0 100%, 100% 100%, 50% 48%)', borderBottom: '1px solid #FFF'}} ></div>
            </div>

            {/* 信封盖 */}
            <div className="absolute top-0 left-0 right-0 h-36 z-40 animate-flap-fold" style={{transformStyle: 'preserve-3d'}}>
              <div className="absolute inset-0 bg-[#FFFDF9] shadow-inner" 
                   style={{clipPath: 'polygon(0 0, 100% 0, 50% 100%)', transform: 'rotateX(-180deg)', backfaceVisibility: 'hidden'}}></div>
              <div className="absolute inset-0 bg-gradient-to-b from-[#FFFDF9] to-[#FFF4EA] shadow-xl border-t border-white" 
                   style={{clipPath: 'polygon(0 0, 100% 0, 50% 100%)', backfaceVisibility: 'hidden'}}>
                  {/* 信封盖上的邮戳装饰 */}
                  <div className="absolute top-4 left-1/2 -translate-x-1/2 opacity-10">
                    <span className="material-symbols-outlined text-4xl text-orange-900">verified</span>
                  </div>
              </div>
            </div>

            {/* 漂浮的小点缀/亮星 */}
            {[...Array(6)].map((_, i) => (
              <div 
                key={i}
                className="absolute z-[45] text-amber-300"
                style={{
                  top: Math.random() * 100 + '%',
                  left: Math.random() * 100 + '%',
                  animation: `sparkle-float ${2 + Math.random() * 2}s ease-in-out infinite`,
                  animationDelay: `${Math.random() * 5}s`
                }}
              >
                <span className="material-symbols-outlined text-xs">auto_awesome</span>
              </div>
            ))}

            {/* 火漆印章 */}
            <div className="absolute top-[55%] left-1/2 z-50 animate-seal-hit">
              <div className="size-16 bg-gradient-to-br from-indigo-700 via-purple-700 to-amber-500 rounded-full shadow-2xl border-4 border-amber-200/40 flex items-center justify-center -translate-x-1/2 -translate-y-1/2 ring-8 ring-purple-900/10">
                 <div className="size-12 rounded-full border border-amber-100/30 flex items-center justify-center bg-purple-900/20 backdrop-blur-sm shadow-inner overflow-visible">
                    <span className="material-symbols-outlined text-amber-300 text-3xl font-black fill-1 translate-x-4">star</span>
                 </div>
              </div>
            </div>
          </div>

          <div className="mt-28 text-center space-y-4 relative z-50">
            <h3 className="text-slate-800 font-black text-2xl tracking-[0.5em] uppercase px-4">穿越时空长河</h3>
            <p className="text-orange-400 text-[11px] font-bold tracking-[0.3em] uppercase opacity-70">Traveling across the river of time</p>
          </div>
        </div>
      )}

      <header className="flex-none px-6 pt-12 pb-4 flex items-center justify-between relative z-10">
        <button onClick={onCancel} className="size-11 flex items-center justify-center bg-white rounded-full shadow-md text-slate-800 active:scale-90 transition-transform border border-slate-100">
          <span className="material-symbols-outlined font-bold">close</span>
        </button>
        <div className="flex flex-col items-center">
          <h2 className="text-slate-900 text-xl font-black tracking-widest">时空信笺</h2>
          <div className="h-0.5 w-8 bg-orange-400 rounded-full mt-0.5"></div>
        </div>
        <div className="w-11"></div>
      </header>

      <main className="flex-1 px-6 pt-4 flex flex-col relative z-10 overflow-hidden">
        <div className="bg-white rounded-[3.5rem] shadow-2xl shadow-orange-900/10 flex flex-col flex-1 border border-orange-100/50 overflow-hidden relative">
          <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none">
             <span className="material-symbols-outlined text-[200px]">history</span>
          </div>

          <div className="px-10 pt-10 pb-6">
            <input 
              type="text" 
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="给未来的自己..."
              className="w-full text-2xl font-black text-slate-900 border-none bg-transparent p-0 focus:ring-0 placeholder:text-slate-200 text-center"
            />
            <div className="w-16 h-1 bg-orange-100 mx-auto mt-4 rounded-full"></div>
          </div>
          
          <div className="flex-1 relative mx-8 mb-4 p-8 bg-[#FFFAF5]/50 rounded-[2.5rem] border border-orange-50/50">
            <textarea 
              autoFocus
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="在这里，写下你想对未来自己说的话..."
              className="w-full h-full text-xl leading-relaxed text-slate-800 border-none bg-transparent p-0 focus:ring-0 placeholder:text-slate-300 resize-none font-serif italic no-scrollbar"
            />
          </div>

          <div className="pt-6 pb-10 border-t border-dashed border-orange-200 flex flex-col items-center bg-orange-50/10">
            <div className="flex items-center gap-3 mb-6 px-6">
              <span className="material-symbols-outlined text-orange-500 text-xl font-bold animate-pulse">schedule</span>
              <label className="text-[11px] font-black text-slate-500 uppercase tracking-widest text-center">拨动转盘，选择封存时光的长度</label>
            </div>

            <div className="relative w-full h-28">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[110px] h-full border-y-2 border-orange-400 bg-orange-50/50 pointer-events-none rounded-[2rem] shadow-inner"></div>
              
              <div className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
              <div className="absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>

              <div 
                ref={rollerRef}
                onScroll={handleScroll}
                className="h-full flex items-center overflow-x-auto snap-x snap-mandatory no-scrollbar"
                style={{ 
                  paddingLeft: 'calc(50% - 55px)', 
                  paddingRight: 'calc(50% - 55px)' 
                }}
              >
                {presets.map((preset, idx) => (
                  <div 
                    key={preset.label}
                    onClick={() => rollerRef.current?.scrollTo({ left: idx * ITEM_WIDTH, behavior: 'smooth' })}
                    className="flex-none w-[110px] snap-center flex flex-col items-center justify-center cursor-pointer transition-all duration-300"
                  >
                    <span className={`text-base font-black transition-all duration-300 ${activeIndex === idx ? 'text-orange-700 scale-125' : 'text-slate-300 scale-90'}`}>
                      {preset.label}
                    </span>
                    {activeIndex === idx && (
                      <div className="size-2 bg-orange-500 rounded-full mt-2 shadow-[0_0_8px_rgba(249,115,22,0.5)]"></div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 flex flex-col items-center gap-1">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                解锁日期：<span className="text-orange-600 font-black">{unlockDate.toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
              </p>
              <p className="text-[9px] text-slate-300 font-bold tracking-tighter">
                这场约会共计跨越了 <span className="text-orange-400">{daysDiff}</span> 个晨昏
              </p>
            </div>
          </div>
        </div>
      </main>

      <div className="flex-none p-8 pb-12 relative z-10">
        <button 
          onClick={handleSave}
          disabled={!content.trim() || isAnimating}
          className="w-full h-18 bg-gradient-to-r from-amber-400 to-orange-500 hover:from-amber-500 hover:to-orange-600 disabled:opacity-30 text-white font-black text-sm uppercase tracking-[0.4em] rounded-[2.2rem] shadow-2xl shadow-orange-200/50 flex items-center justify-center gap-4 active:scale-[0.98] transition-all group border-2 border-white/30"
        >
          {isAnimating ? (
             <span className="animate-pulse">时光封存中...</span>
          ) : (
            <>
              <span>封存此刻好心情</span>
              <span className="material-symbols-outlined text-2xl group-hover:rotate-12 transition-transform">auto_awesome</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default FutureLetterEntry;
