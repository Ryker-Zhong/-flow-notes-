import React, { useState, useMemo, useEffect } from 'react';
import { Note, Badge, ThemeConfig } from '../types';

interface ReviewProps {
  notes: Note[];
  onMoodLogged?: (moodIndex: number) => void;
  confirmedMood: number | null;
  stablePastData: { weeklyPast: number[], monthlyPast: number[] };
  badges: Badge[];
  theme: ThemeConfig;
}

const Review: React.FC<ReviewProps> = ({ notes, onMoodLogged, confirmedMood, stablePastData, badges, theme }) => {
  const [selectedMood, setSelectedMood] = useState<number | null>(confirmedMood);
  const [isMoodConfirmed, setIsMoodConfirmed] = useState(confirmedMood !== null);
  const [showAllBadges, setShowAllBadges] = useState(false);
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);

  useEffect(() => {
    if (confirmedMood !== null) {
      setSelectedMood(confirmedMood);
      setIsMoodConfirmed(true);
    }
  }, [confirmedMood]);

  const moods = [
    { emoji: "😿", label: "难过", score: 20, color: "bg-blue-100 text-blue-500", hex: "#93C5FD" }, 
    { emoji: "😾", label: "生气", score: 40, color: "bg-red-100 text-red-500", hex: "#FCA5A5" },   
    { emoji: "🐱", label: "平静", score: 60, color: "bg-slate-100 text-slate-500", hex: "#CBD5E1" }, 
    { emoji: "😸", label: "开心", score: 80, color: "bg-amber-100 text-amber-500", hex: "#FCD34D" }, 
    { emoji: "😻", label: "极好", score: 100, color: "bg-rose-100 text-rose-500", hex: "#FB7185" },  
  ];

  const handleMoodSelect = (idx: number) => {
    if (isMoodConfirmed) return;
    setSelectedMood(idx);
  };

  const handleConfirm = () => {
    if (selectedMood !== null && !isMoodConfirmed) {
        setIsMoodConfirmed(true);
        if (onMoodLogged) {
            onMoodLogged(selectedMood);
        }
    }
  };

  const dashboardData = useMemo(() => {
    const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
    const todayIndex = new Date().getDay() === 0 ? 6 : new Date().getDay() - 1;
    
    const weeklyTrend = days.map((day, index) => {
      if (index > todayIndex) return { day, moodIndex: null, isFuture: true };
      if (index === todayIndex) return { day, moodIndex: selectedMood, isToday: true };
      return { day, moodIndex: stablePastData.weeklyPast[index % 6], isPast: true }; 
    });

    const moodCounts = [0, 0, 0, 0, 0];
    let recordedDaysCount = 0;

    weeklyTrend.forEach(item => {
        if (item.moodIndex !== null) {
            moodCounts[item.moodIndex]++;
            recordedDaysCount++;
        }
    });

    const radius = 40;
    const circumference = 2 * Math.PI * radius;
    let accumulatedPercent = 0;

    const pieSegments = moodCounts.map((count, index) => {
        if (count === 0 || recordedDaysCount === 0) return null;
        const percent = count / recordedDaysCount;
        const dashArray = percent * circumference;
        const dashOffset = -accumulatedPercent * circumference;
        accumulatedPercent += percent;
        
        return {
            index,
            dashArray,
            dashOffset,
            color: moods[index].hex,
            percent,
            count
        };
    }).filter(Boolean);


    const monthlyCounts = [...stablePastData.monthlyPast];
    if (selectedMood !== null) {
        monthlyCounts[selectedMood]++;
    }
    const totalDays = 29 + (selectedMood !== null ? 1 : 0);
    const bestMoodCount = monthlyCounts[4] + monthlyCounts[3];
    const totalScore = monthlyCounts.reduce((acc, count, idx) => acc + count * ((idx + 1) * 20), 0);
    const avgScore = Math.round(totalScore / totalDays) || 0;

    return { 
        weeklyTrend, 
        pieSegments, 
        recordedDaysCount,
        monthlyCounts, 
        totalDays, 
        avgScore, 
        bestMoodCount 
    };
  }, [selectedMood, stablePastData]);

  const shouldShowMore = badges.length > 4;
  const visibleBadges = showAllBadges ? badges : (shouldShowMore ? badges.slice(0, 3) : badges);

  return (
    <div className="h-full flex flex-col no-scrollbar overflow-y-auto fade-in bg-[#FDF2F8] relative">
      <header className="px-6 pt-10 pb-4 flex justify-between items-start flex-none">
        <div>
          <p className="text-slate-400 text-xs font-medium mb-1">每日回顾</p>
          <h2 className="text-slate-900 text-2xl font-bold">{new Date().toLocaleDateString('zh-CN', { month: 'short', day: 'numeric', weekday: 'long' })}</h2>
        </div>
      </header>

      <div className="flex-1 pb-24">
        <section className="px-6 py-4 relative z-10">
            <h3 className="text-slate-800 text-xl font-bold mb-6">
                {isMoodConfirmed ? "今日心情已记录" : "今天过得还好吗？"}
            </h3>
            
            <div className={`bg-white rounded-[2.5rem] p-6 shadow-sm border border-white transition-all duration-500 ${isMoodConfirmed ? 'bg-white/40' : 'shadow-xl ' + theme.colors.shadow}`}>
            
            <div className="flex justify-between items-center px-2">
                {moods.map((mood, idx) => (
                <button
                    key={idx}
                    onClick={() => handleMoodSelect(idx)}
                    disabled={isMoodConfirmed}
                    className={`size-14 flex items-center justify-center text-4xl rounded-full transition-all duration-300 ${
                    selectedMood === idx 
                    ? (isMoodConfirmed ? 'scale-125 grayscale-0' : 'bg-[#E0E7FF] scale-110 shadow-inner ring-2 ring-indigo-100') 
                    : (isMoodConfirmed ? 'opacity-20 grayscale scale-90' : 'hover:bg-slate-50 opacity-60 grayscale-[0.5]')
                    }`}
                >
                    {mood.emoji}
                </button>
                ))}
            </div>

            {selectedMood !== null && !isMoodConfirmed && (
                <div className="mt-6 pt-6 border-t border-slate-100 animate-in slide-in-from-top-2 fade-in duration-300">
                    <button 
                        onClick={handleConfirm}
                        className="w-full h-14 bg-slate-900 text-white rounded-2xl font-bold text-base shadow-lg shadow-slate-900/20 flex items-center justify-center gap-2 active:scale-[0.98] transition-all hover:bg-slate-800"
                    >
                        确认心情
                        <span className="material-symbols-outlined text-xl">check_circle</span>
                    </button>
                </div>
            )}
            
            {isMoodConfirmed && (
                <div className="mt-4 pt-4 border-t border-slate-50 text-center animate-in fade-in duration-700">
                    <p className={`text-[10px] font-black tracking-[0.3em] uppercase ${theme.colors.secondary}`}>Today's Mood is Sealed</p>
                </div>
            )}
            </div>
        </section>

        <div className="animate-in slide-in-from-bottom-10 fade-in duration-700 delay-100 space-y-6 px-6 mt-2">
            <div className="bg-white/60 backdrop-blur-md rounded-[2.2rem] p-7 border border-white shadow-sm">
                <div className="flex items-center justify-between mb-6">
                    <h4 className="text-slate-800 font-bold text-xl">本周分布</h4>
                    <span className="px-3 py-1 bg-white rounded-full text-[10px] font-black text-slate-400 shadow-sm border border-slate-50">WEEKLY</span>
                </div>
                
                <div className="flex items-center gap-6">
                    <div className="relative size-36 shrink-0">
                        <svg viewBox="0 0 100 100" className="rotate-[-90deg] size-full drop-shadow-lg">
                            <circle cx="50" cy="50" r="40" fill="none" stroke="#F1F5F9" strokeWidth="12" />
                            {dashboardData.pieSegments.map((seg, i) => (
                                <circle 
                                    key={i}
                                    cx="50" cy="50" r="40" 
                                    fill="none" 
                                    stroke={seg?.color} 
                                    strokeWidth="12"
                                    strokeDasharray={`${seg?.dashArray} 251.2`}
                                    strokeDashoffset={seg?.dashOffset}
                                    strokeLinecap="round"
                                    className="transition-all duration-1000 ease-out"
                                />
                            ))}
                        </svg>
                        
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                            <span className="text-3xl font-black text-slate-800">{dashboardData.recordedDaysCount}</span>
                            <span className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">天记录</span>
                        </div>
                    </div>

                    <div className="flex flex-col gap-3 flex-1">
                        {dashboardData.pieSegments.length > 0 ? (
                            [...dashboardData.pieSegments].sort((a,b) => (b?.percent || 0) - (a?.percent || 0)).map((seg, i) => {
                                if (!seg) return null;
                                const mood = moods[seg.index];
                                return (
                                    <div key={i} className="flex items-center justify-between group">
                                        <div className="flex items-center gap-2">
                                            <div className="size-3 rounded-full" style={{ backgroundColor: seg.color }}></div>
                                            <span className="text-xs font-bold text-slate-600">{mood.label}</span>
                                        </div>
                                        <span className="text-xs font-black text-slate-400">{seg.count} 天</span>
                                    </div>
                                )
                            })
                        ) : (
                             <div className="text-center py-4">
                                <p className="text-xs text-slate-400">暂无足够数据</p>
                             </div>
                        )}
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#FFFDF9] p-6 rounded-[2.2rem] shadow-sm border border-orange-50 relative overflow-hidden">
                        <div className="absolute -right-4 -top-4 size-20 bg-amber-100/50 rounded-full blur-2xl"></div>
                        <div className="flex justify-between items-start mb-1">
                             <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">心情指数</p>
                        </div>
                        <div className="flex items-baseline gap-1">
                            <span className="text-4xl font-black text-slate-800 transition-all duration-500">{dashboardData.avgScore}</span>
                            <span className="text-xs font-bold text-slate-300">/ 100</span>
                        </div>
                        <div className="flex gap-1 mt-4 h-3 w-full">
                            {[...Array(10)].map((_, i) => (
                                <div key={i} className={`flex-1 rounded-sm transition-all duration-500 ${
                                    i < Math.round(dashboardData.avgScore / 10) 
                                    ? 'bg-amber-400 shadow-[0_2px_5px_rgba(251,191,36,0.3)]' 
                                    : 'bg-slate-100'
                                }`}></div>
                            ))}
                        </div>
                </div>

                <div className="bg-[#F0FDFA] p-6 rounded-[2.2rem] shadow-sm border border-teal-50 relative overflow-hidden">
                    <div className="absolute -right-4 -top-4 size-20 bg-teal-100/50 rounded-full blur-2xl"></div>
                    <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">开心天数</p>
                        <div className="flex items-baseline gap-1">
                            <span className="text-4xl font-black text-teal-800 transition-all duration-500">{dashboardData.bestMoodCount}</span>
                            <span className="text-xs font-bold text-teal-400/70">天</span>
                        </div>
                        <p className="text-[10px] text-teal-600/60 mt-2 font-medium">本月占比 {Math.round((dashboardData.bestMoodCount / 30) * 100)}%</p>
                </div>
            </div>

            <div className="pt-4 pb-8 animate-in slide-in-from-bottom-5 fade-in duration-700 delay-150">
                <div className="flex items-center justify-between mb-5 px-2">
                    <div className="flex items-center gap-2">
                        <span className="material-symbols-outlined text-amber-500">military_tech</span>
                        <h4 className="text-slate-800 font-bold text-lg tracking-tight">成就勋章</h4>
                    </div>
                    <span className="text-[10px] font-black text-slate-400 bg-white/60 px-2.5 py-1 rounded-full border border-white shadow-sm">
                        {badges.filter(b => b.unlocked).length} / {badges.length} 已解锁
                    </span>
                </div>
                
                <div className="grid grid-cols-4 gap-2">
                    {visibleBadges.map(badge => (
                        <div 
                            key={badge.id} 
                            onClick={() => setSelectedBadge(badge)}
                            className="flex flex-col items-center gap-2 group relative cursor-pointer"
                        >
                            <div className={`size-16 rounded-full flex items-center justify-center shadow-md border-2 border-white transition-all duration-300 relative overflow-hidden ${
                                badge.unlocked 
                                ? `bg-gradient-to-br ${badge.color} scale-100 group-hover:scale-105 group-hover:shadow-xl` 
                                : 'bg-slate-100 opacity-60 grayscale'
                            }`}>
                                {badge.unlocked && (
                                    <div className="absolute inset-0 bg-white/20 animate-[pulse_3s_infinite]"></div>
                                )}
                                <span className={`material-symbols-outlined text-3xl relative z-10 ${badge.unlocked ? 'text-white drop-shadow-md' : 'text-slate-300'}`}>
                                    {badge.icon}
                                </span>
                            </div>
                            
                            <div className="text-center w-full">
                                <span className={`text-[10px] font-black block truncate px-1 transition-colors ${badge.unlocked ? 'text-slate-700' : 'text-slate-400'}`}>
                                    {badge.name}
                                </span>
                            </div>
                        </div>
                    ))}
                    
                    {!showAllBadges && shouldShowMore && (
                        <button 
                            onClick={() => setShowAllBadges(true)}
                            className="flex flex-col items-center gap-2 group"
                        >
                            <div className="size-16 rounded-full flex items-center justify-center shadow-sm border-2 border-dashed border-slate-300 bg-white/50 text-slate-400 hover:bg-slate-100 hover:text-slate-500 hover:border-slate-400 transition-all">
                                <span className="material-symbols-outlined text-2xl">more_horiz</span>
                            </div>
                            <span className="text-[10px] font-bold text-slate-400">更多</span>
                        </button>
                    )}

                    {showAllBadges && (
                        <button 
                            onClick={() => setShowAllBadges(false)}
                            className="flex flex-col items-center gap-2 group"
                        >
                            <div className="size-16 rounded-full flex items-center justify-center shadow-sm border-2 border-dashed border-slate-300 bg-white/50 text-slate-400 hover:bg-slate-100 hover:text-slate-500 hover:border-slate-400 transition-all">
                                <span className="material-symbols-outlined text-2xl">expand_less</span>
                            </div>
                            <span className="text-[10px] font-bold text-slate-400">收起</span>
                        </button>
                    )}
                </div>
            </div>
        </div>
      </div>

      {selectedBadge && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 animate-in fade-in duration-200">
            <div 
                className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" 
                onClick={() => setSelectedBadge(null)}
            ></div>
            <div className="relative bg-white w-full max-w-sm rounded-[2.5rem] p-8 pb-10 shadow-2xl animate-in zoom-in-95 duration-300 flex flex-col items-center text-center">
                <button 
                    onClick={() => setSelectedBadge(null)}
                    className="absolute top-4 right-4 size-10 flex items-center justify-center bg-slate-50 text-slate-400 rounded-full hover:bg-slate-100 transition-colors"
                >
                    <span className="material-symbols-outlined">close</span>
                </button>

                <div className={`size-32 rounded-full flex items-center justify-center mb-6 shadow-xl relative overflow-hidden ${
                    selectedBadge.unlocked 
                    ? `bg-gradient-to-br ${selectedBadge.color}` 
                    : 'bg-slate-100 grayscale'
                }`}>
                    {selectedBadge.unlocked && (
                         <div className="absolute inset-0 bg-white/20 animate-[pulse_3s_infinite]"></div>
                    )}
                    <span className={`material-symbols-outlined text-6xl relative z-10 ${selectedBadge.unlocked ? 'text-white' : 'text-slate-300'}`}>
                        {selectedBadge.icon}
                    </span>
                </div>

                <h3 className="text-2xl font-black text-slate-900 mb-2 tracking-tight">{selectedBadge.name}</h3>
                
                <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest mb-6 border ${
                    selectedBadge.unlocked 
                    ? 'bg-amber-50 text-amber-600 border-amber-100' 
                    : 'bg-slate-50 text-slate-400 border-slate-100'
                }`}>
                    {selectedBadge.unlocked ? '已解锁 Achievement Unlocked' : '未解锁 Locked'}
                </span>

                <p className="text-slate-500 font-medium leading-relaxed px-2 text-sm">
                    {selectedBadge.desc}
                </p>
                
                <div className="mt-8 w-full">
                    <button 
                    onClick={() => setSelectedBadge(null)}
                    className={`w-full py-4 rounded-2xl font-bold text-sm transition-all shadow-lg active:scale-95 ${
                        selectedBadge.unlocked 
                        ? 'bg-slate-900 text-white shadow-slate-900/20 hover:bg-slate-800' 
                        : 'bg-slate-100 text-slate-400 shadow-slate-200/50 hover:bg-slate-200'
                    }`}
                    >
                    {selectedBadge.unlocked ? '太棒了' : '继续加油'}
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default Review;