import React, { useMemo } from 'react';
import { Reminder, ThemeConfig } from '../types';

interface NotificationsViewProps {
  reminders: Reminder[];
  theme: ThemeConfig;
  onBack: () => void;
  onToggleReminder: (id: number) => void;
}

const NotificationsView: React.FC<NotificationsViewProps> = ({ reminders, theme, onBack, onToggleReminder }) => {
  // Filter for active (uncompleted) reminders sorted by time
  const upcomingReminders = useMemo(() => {
    return reminders
      .filter(r => !r.completed)
      .sort((a, b) => (a.dueTimestamp || 0) - (b.dueTimestamp || 0));
  }, [reminders]);

  const completedReminders = useMemo(() => {
    return reminders.filter(r => r.completed);
  }, [reminders]);

  const mockSystemNotifications = [
    { id: 's1', title: '系统更新', content: '心流笔记已更新至 v2.3.0，新增了时间胶囊功能。', time: '2小时前', icon: 'update', color: 'bg-blue-100 text-blue-500' },
    { id: 's2', title: '新的勋章', content: '恭喜你获得了“深夜哲思”勋章！', time: '昨天', icon: 'military_tech', color: 'bg-amber-100 text-amber-500' },
  ];

  return (
    <div className="h-full flex flex-col no-scrollbar overflow-y-auto fade-in bg-[#FFFDF9] relative">
      <header className="px-6 pt-12 pb-6 flex items-center gap-4 sticky top-0 bg-[#FFFDF9]/90 backdrop-blur-md z-10">
        <button 
          onClick={onBack} 
          className="size-10 flex items-center justify-center bg-white rounded-full shadow-sm text-slate-400 border border-slate-100 active:scale-95 transition-transform"
        >
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
        <h2 className="text-slate-900 text-xl font-bold">消息中心</h2>
      </header>

      <div className="px-6 pb-24 space-y-8">
        
        {/* Upcoming Reminders Section */}
        <section>
          <div className="flex items-center gap-2 mb-4">
             <span className={`material-symbols-outlined ${theme.colors.secondary}`}>alarm</span>
             <h3 className="text-slate-800 font-bold text-lg">即将待办</h3>
             <span className={`ml-auto text-xs font-bold px-2 py-0.5 rounded-md ${theme.colors.secondaryBg} ${theme.colors.secondary}`}>
                {upcomingReminders.length}
             </span>
          </div>

          <div className="space-y-3">
            {upcomingReminders.length > 0 ? (
              upcomingReminders.map(reminder => (
                <div 
                  key={reminder.id}
                  className={`bg-white p-4 rounded-[1.5rem] border border-slate-50 shadow-sm flex items-start gap-4 transition-all hover:shadow-md ${reminder.isDailyEssential ? 'ring-1 ring-amber-100 bg-amber-50/30' : ''}`}
                >
                  <button 
                    onClick={() => onToggleReminder(reminder.id)}
                    className={`shrink-0 size-6 rounded-full border-2 flex items-center justify-center mt-0.5 transition-colors ${theme.colors.border} hover:bg-slate-50`}
                  >
                  </button>
                  <div className="flex-1">
                     <div className="flex justify-between items-start">
                        <h4 className="text-slate-800 font-bold text-sm leading-snug">{reminder.text}</h4>
                        <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-md whitespace-nowrap ml-2 ${
                            reminder.isDailyEssential ? 'bg-amber-100 text-amber-600' : 'bg-slate-100 text-slate-400'
                        }`}>
                            {reminder.time}
                        </span>
                     </div>
                     {reminder.dueTimestamp && (
                        <p className="text-xs text-slate-400 mt-1">
                           {(reminder.dueTimestamp - Date.now()) > 0 
                             ? `还有 ${Math.ceil((reminder.dueTimestamp - Date.now()) / 60000)} 分钟`
                             : '已到期'
                           }
                        </p>
                     )}
                  </div>
                </div>
              ))
            ) : (
              <div className="py-8 text-center bg-slate-50/50 rounded-3xl border border-dashed border-slate-200">
                <p className="text-slate-400 text-xs">暂无待办事项，去首页添加吧</p>
              </div>
            )}
          </div>
        </section>

        {/* System Notifications Section */}
        <section>
          <div className="flex items-center gap-2 mb-4">
             <span className="material-symbols-outlined text-slate-400">notifications</span>
             <h3 className="text-slate-800 font-bold text-lg">系统通知</h3>
          </div>
          <div className="space-y-4">
             {mockSystemNotifications.map(notif => (
                 <div key={notif.id} className="flex gap-4 items-start">
                     <div className={`size-10 rounded-2xl flex items-center justify-center shrink-0 ${notif.color}`}>
                         <span className="material-symbols-outlined text-xl">{notif.icon}</span>
                     </div>
                     <div className="flex-1 border-b border-slate-50 pb-4">
                         <div className="flex justify-between items-center mb-1">
                             <h4 className="text-slate-800 font-bold text-sm">{notif.title}</h4>
                             <span className="text-[10px] text-slate-300 font-bold">{notif.time}</span>
                         </div>
                         <p className="text-slate-500 text-xs leading-relaxed">{notif.content}</p>
                     </div>
                 </div>
             ))}
          </div>
        </section>

        {/* Completed History (Optional/Collapsible) */}
        {completedReminders.length > 0 && (
            <section className="opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
                <div className="flex items-center gap-2 mb-4 mt-8">
                    <span className="material-symbols-outlined text-slate-400">task_alt</span>
                    <h3 className="text-slate-800 font-bold text-lg">已完成</h3>
                </div>
                <div className="space-y-2">
                    {completedReminders.map(reminder => (
                        <div key={reminder.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-2xl">
                             <div className="size-5 rounded-full bg-emerald-100 text-emerald-500 flex items-center justify-center">
                                 <span className="material-symbols-outlined text-sm font-bold">check</span>
                             </div>
                             <p className="text-slate-400 text-xs line-through">{reminder.text}</p>
                        </div>
                    ))}
                </div>
            </section>
        )}

      </div>
    </div>
  );
};

export default NotificationsView;