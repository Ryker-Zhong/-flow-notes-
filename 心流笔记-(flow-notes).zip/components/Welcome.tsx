import React from 'react';

interface WelcomeProps {
  onStart: () => void;
}

const Welcome: React.FC<WelcomeProps> = ({ onStart }) => {
  return (
    <div className="h-full flex flex-col p-6 fade-in relative overflow-hidden">
      {/* Background Orbs */}
      <div className="fixed top-[-10%] right-[-10%] w-[70%] h-[40%] bg-yellow-200/30 rounded-full blur-[80px] pointer-events-none"></div>
      <div className="fixed bottom-[-5%] left-[-15%] w-[60%] h-[35%] bg-pink-300/20 rounded-full blur-[70px] pointer-events-none"></div>

      <div className="mt-12 text-center space-y-2 relative z-10">
        <h1 className="text-4xl font-bold tracking-tight text-slate-900 leading-tight">
          欢迎来到<br/>
          <span className="text-primary-accent">心流笔记</span>
        </h1>
      </div>

      <div className="flex-1 flex items-center justify-center relative z-10 py-10">
        <div className="relative w-full aspect-[4/5] max-h-[380px]">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] h-[90%] bg-white/70 rounded-[2.5rem] -rotate-3 border border-white/50 shadow-lg"></div>
          <div className="absolute inset-0 rounded-[2.5rem] overflow-hidden shadow-2xl rotate-2 ring-1 ring-black/5">
            <img 
              alt="Person writing illustration" 
              className="w-full h-full object-cover opacity-90" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuB-8q43MHFp6U5hYsZBMLsl9H9RWtghHtw1sxa_L-eJeuxV1hmJvcgeqBQsA1FbMQmCV7MbMyaCt5ItVY-qchI-aM-ENJjWiZhwZK5bcLe4vdfBm1_-xbhRh4ca_aS8mZ4LSfefode1KEf2mhQdhAMbwG9NokYRd9QgiGW9YLD_gIM6DuWn4qDa9QU1N1IAuw0VAm1W_WLuS_Ld4SsuVv8dGgNN_mrf5yFkQMUanxsLd9rcgej3Sai-aAHpl_5CEpK0Gg_80RMxsBs" 
            />
          </div>
          {/* Floating Icons */}
          <div className="absolute -right-2 top-10 bg-white p-3.5 rounded-2xl shadow-xl rotate-6 animate-bounce">
            <span className="material-symbols-outlined text-rose-400 text-2xl">edit_note</span>
          </div>
          <div className="absolute -left-2 bottom-20 bg-white p-3.5 rounded-2xl shadow-xl -rotate-6 animate-pulse">
            <span className="material-symbols-outlined text-amber-400 text-2xl">wb_sunny</span>
          </div>
        </div>
      </div>

      <div className="text-center px-4 space-y-8 relative z-10 pb-10">
        <p className="text-lg text-slate-600 font-medium leading-relaxed">
          复盘每日得失，捕捉灵感瞬间，<br/>见证每日成长。
        </p>
        
        <div className="space-y-4">
          <button 
            onClick={onStart}
            className="w-full h-14 bg-slate-900 hover:bg-slate-800 text-white font-bold text-lg rounded-2xl shadow-xl shadow-slate-900/10 transition-all flex items-center justify-center gap-2 group active:scale-[0.98]"
          >
            立即开始
            <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform">arrow_forward</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Welcome;