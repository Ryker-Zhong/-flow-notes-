
import React, { useState, useEffect, useRef } from 'react';
import { Note, ReflectionQuestion, ReflectionType } from '../types';
import { summarizeDay } from '../services/geminiService';

interface ReflectionFlowProps {
  type: ReflectionType;
  questions: ReflectionQuestion[];
  onCancel: () => void;
  onComplete: (note: Note) => void;
}

const ReflectionFlow: React.FC<ReflectionFlowProps> = ({ type, questions, onCancel, onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<string[]>(new Array(questions.length).fill(""));
  const [isSubmitting, setIsSubmitting] = useState(false);
  const textAreaRef = useRef<HTMLTextAreaElement>(null);

  const currentQuestion = questions[currentStep];
  const progress = questions.length > 0 ? ((currentStep + 1) / questions.length) * 100 : 0;
  
  const isDaily = type === ReflectionType.DAILY;
  const themeColor = isDaily ? 'rose' : 'indigo';

  useEffect(() => {
    textAreaRef.current?.focus();
  }, [currentStep]);

  if (questions.length === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-10 text-center bg-white">
        <span className="material-symbols-outlined text-6xl text-slate-200 mb-4">quiz</span>
        <h3 className="text-xl font-bold text-slate-800">尚未设置复盘问题</h3>
        <p className="text-slate-400 mt-2">请先在“我的”页面自定义复盘模板。</p>
        <button onClick={onCancel} className="mt-8 px-8 py-3 bg-slate-900 text-white rounded-xl font-bold">返回首页</button>
      </div>
    );
  }

  const handleNext = async () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      setIsSubmitting(true);
      try {
        const summary = await summarizeDay(questions.map((q, i) => ({ questionText: q.text, answer: answers[i] })));
        const newNote: Note = {
          id: Math.random().toString(36).substr(2, 9),
          title: isDaily ? summary : `[事件复盘] ${summary}`,
          content: answers.join('\n\n'),
          category: isDaily ? '个人' : '灵感',
          type: isDaily ? 'REFLECTION_DAILY' : 'REFLECTION_EVENT',
          timestamp: new Date()
        };
        onComplete(newNote);
      } catch (error) {
        console.error("Failed to summarize:", error);
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  return (
    <div className={`h-full flex flex-col fade-in bg-gradient-to-br from-white to-${themeColor}-50/30`}>
      <header className="flex-none px-4 pt-6 pb-2">
        <div className="flex items-center justify-between">
          <button onClick={onCancel} className="size-10 flex items-center justify-center hover:bg-white rounded-full transition-all text-slate-400">
            <span className="material-symbols-outlined">close</span>
          </button>
          <h2 className="text-slate-900 text-lg font-bold">
            {isDaily ? '每日复盘' : '重要事情复盘'}
          </h2>
          <div className="w-10"></div>
        </div>
      </header>

      <div className="px-8 py-4">
        <div className="flex justify-between items-end mb-3">
          <div>
            <span className={`text-${themeColor}-500 text-2xl font-black`}>{currentStep + 1}</span>
            <span className="text-slate-300 text-lg font-bold"> / {questions.length}</span>
          </div>
          <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">进度 {Math.round(progress)}%</p>
        </div>
        <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden p-0.5">
          <div 
            className={`h-full bg-gradient-to-r from-${themeColor}-400 to-amber-300 rounded-full transition-all duration-700 ease-out shadow-[0_0_10px_rgba(244,63,94,0.3)]`}
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      <main className="flex-1 overflow-y-auto px-6 pt-6 no-scrollbar pb-40">
        <div className="flex items-start gap-4 mb-8">
          <div className={`size-12 rounded-2xl bg-white shadow-lg shadow-${themeColor}-500/5 flex items-center justify-center text-${themeColor}-500 shrink-0`}>
            <span className="material-symbols-outlined text-3xl leading-none">{currentQuestion.icon}</span>
          </div>
          <h3 className="text-2xl font-black text-slate-900 leading-tight pt-1">
            {currentQuestion.text}
          </h3>
        </div>

        <div className="relative">
          <textarea 
            ref={textAreaRef}
            value={answers[currentStep]}
            onChange={(e) => {
              const newAnswers = [...answers];
              newAnswers[currentStep] = e.target.value;
              setAnswers(newAnswers);
            }}
            placeholder={currentQuestion.placeholder}
            className={`w-full min-h-[300px] p-8 rounded-[2.5rem] bg-white border-2 border-white focus:border-${themeColor}-100 focus:ring-0 text-slate-800 text-lg leading-relaxed placeholder:text-slate-200 resize-none transition-all shadow-xl shadow-${themeColor}-900/5`}
          />
        </div>
      </main>

      <div className="fixed bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-[#FFFDF9] via-[#FFFDF9]/90 to-transparent z-20">
        <button 
          onClick={handleNext}
          disabled={!answers[currentStep].trim() || isSubmitting}
          className="w-full h-16 bg-slate-900 hover:bg-slate-800 disabled:opacity-20 text-white font-black text-sm uppercase tracking-[0.2em] rounded-2xl shadow-2xl shadow-slate-900/20 flex items-center justify-center gap-3 active:scale-[0.98] transition-all"
        >
          {isSubmitting ? (
            <span className="flex items-center gap-2">
              <span className="animate-spin material-symbols-outlined">sync</span>
              处理中...
            </span>
          ) : (
            <>
              {currentStep === questions.length - 1 ? '完成复盘并保存' : '进入下一步'}
              <span className="material-symbols-outlined">
                {currentStep === questions.length - 1 ? 'task_alt' : 'east'}
              </span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default ReflectionFlow;
