import React from 'react';
import { ThemeConfig } from '../types';

interface PrivacyViewProps {
  onBack: () => void;
  theme: ThemeConfig;
}

const PrivacyView: React.FC<PrivacyViewProps> = ({ onBack, theme }) => {
  return (
    <div className="h-full flex flex-col no-scrollbar overflow-y-auto fade-in bg-[#FFFDF9] relative">
      <header className="px-6 pt-12 pb-6 flex items-center gap-4 sticky top-0 bg-[#FFFDF9]/90 backdrop-blur-md z-10">
        <button 
          onClick={onBack} 
          className="size-10 flex items-center justify-center bg-white rounded-full shadow-sm text-slate-400 border border-slate-100 active:scale-95 transition-transform"
        >
          <span className="material-symbols-outlined">arrow_back</span>
        </button>
        <h2 className="text-slate-900 text-xl font-bold">隐私与安全</h2>
      </header>

      <div className="px-6 pb-24 space-y-6">
        
        {/* Creator Info Card */}
        <div className={`w-full bg-white rounded-[2.5rem] p-8 shadow-xl border border-white text-center relative overflow-hidden group`}>
            <div className={`absolute -right-10 -top-10 size-32 bg-gradient-to-br ${theme.gradient} opacity-20 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700`}></div>
            
            <div className={`size-20 mx-auto rounded-full bg-slate-50 flex items-center justify-center mb-6 shadow-inner ${theme.colors.secondary}`}>
                <span className="material-symbols-outlined text-4xl">admin_panel_settings</span>
            </div>

            <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.3em] mb-2">Creator ID</p>
            <h3 className={`text-2xl font-black mb-4 tracking-tight ${theme.colors.primary}`}>柚子欧尼酱</h3>
            
            <div className="flex justify-center gap-2 mb-8">
                 <span className="px-3 py-1 bg-slate-100 rounded-full text-[10px] font-bold text-slate-500">
                    Developer
                 </span>
                 <span className={`px-3 py-1 rounded-full text-[10px] font-bold ${theme.colors.secondaryBg} ${theme.colors.secondary}`}>
                    Verified
                 </span>
            </div>

            {/* Contact Info */}
            <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-slate-50/50 rounded-2xl border border-slate-100 transition-colors hover:bg-slate-50">
                     <div className="flex items-center gap-3">
                        <div className="size-8 bg-white rounded-full flex items-center justify-center shadow-sm text-slate-400">
                            <span className="material-symbols-outlined text-sm">code</span>
                        </div>
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">GitHub</span>
                     </div>
                     <span className="text-xs font-black text-slate-700 select-all bg-white px-2 py-1 rounded-lg border border-slate-100">Ryker-Zhong</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-slate-50/50 rounded-2xl border border-slate-100 transition-colors hover:bg-slate-50">
                     <div className="flex items-center gap-3">
                        <div className="size-8 bg-white rounded-full flex items-center justify-center shadow-sm text-slate-400">
                            <span className="material-symbols-outlined text-sm">chat</span>
                        </div>
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">WeChat</span>
                     </div>
                     <span className="text-xs font-black text-slate-700 select-all bg-white px-2 py-1 rounded-lg border border-slate-100">Jasmine_YZ822</span>
                </div>

                <div className="flex items-center justify-between p-3 bg-slate-50/50 rounded-2xl border border-slate-100 transition-colors hover:bg-slate-50">
                     <div className="flex items-center gap-3">
                        <div className="size-8 bg-white rounded-full flex items-center justify-center shadow-sm text-slate-400">
                            <span className="material-symbols-outlined text-sm">handshake</span>
                        </div>
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">协助者ID</span>
                     </div>
                     <span className="text-xs font-black text-slate-700 select-all bg-white px-2 py-1 rounded-lg border border-slate-100">yify</span>
                </div>
            </div>
        </div>

        {/* Security Info */}
        <div className="space-y-4">
             <h4 className="text-slate-400 text-xs font-bold uppercase tracking-widest px-2 mt-4">数据安全</h4>
             
             <div className="bg-white p-5 rounded-[2rem] border border-slate-50 shadow-sm flex items-start gap-4">
                 <span className={`material-symbols-outlined text-2xl ${theme.colors.secondary}`}>lock</span>
                 <div>
                     <h5 className="text-slate-800 font-bold text-sm mb-1">本地存储优先</h5>
                     <p className="text-slate-500 text-xs leading-relaxed">您的日记和数据主要存储在本地设备中，确保最大程度的隐私安全。</p>
                 </div>
             </div>

             <div className="bg-white p-5 rounded-[2rem] border border-slate-50 shadow-sm flex items-start gap-4">
                 <span className={`material-symbols-outlined text-2xl ${theme.colors.secondary}`}>cloud_off</span>
                 <div>
                     <h5 className="text-slate-800 font-bold text-sm mb-1">无痕浏览</h5>
                     <p className="text-slate-500 text-xs leading-relaxed">应用不会收集您的个人身份信息用于第三方广告推送。</p>
                 </div>
             </div>
        </div>

        <div className="pt-10 text-center">
            <p className="text-slate-300 text-[10px]">Privacy Policy • Terms of Service</p>
            <p className="text-slate-300 text-[10px] mt-1">© 2024 Flow Notes. All rights reserved.</p>
        </div>

      </div>
    </div>
  );
};

export default PrivacyView;