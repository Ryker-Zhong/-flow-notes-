import React, { useState, useEffect } from 'react';

interface CustomCalendarProps {
  value: Date;
  onChange: (date: Date) => void;
  onClose: () => void;
}

const WEEKDAYS = ['一', '二', '三', '四', '五', '六', '日'];
const MONTHS = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];

const CustomCalendar: React.FC<CustomCalendarProps> = ({ value, onChange, onClose }) => {
  const [viewDate, setViewDate] = useState(new Date(value));
  const [isMonthPickerOpen, setIsMonthPickerOpen] = useState(false);
  
  useEffect(() => {
    if (value) {
       // Only update if the month/year is different to avoid jumping focus
       if (value.getMonth() !== viewDate.getMonth() || value.getFullYear() !== viewDate.getFullYear()) {
           setViewDate(new Date(value));
       }
    }
  }, [value]);

  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    let day = new Date(year, month, 1).getDay();
    day = day === 0 ? 6 : day - 1;
    return day;
  };

  const generateDays = () => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);
    
    const days = [];
    
    // Prev Month padding
    const prevMonthDays = getDaysInMonth(year, month - 1);
    for (let i = 0; i < firstDay; i++) {
        days.push({
            day: prevMonthDays - firstDay + 1 + i,
            currentMonth: false,
            date: new Date(year, month - 1, prevMonthDays - firstDay + 1 + i)
        });
    }

    // Current Month
    for (let i = 1; i <= daysInMonth; i++) {
        days.push({
            day: i,
            currentMonth: true,
            date: new Date(year, month, i)
        });
    }

    // Next Month padding
    const totalSlots = 42; 
    const remaining = totalSlots - days.length;
    for (let i = 1; i <= remaining; i++) {
        days.push({
            day: i,
            currentMonth: false,
            date: new Date(year, month + 1, i)
        });
    }
    return days;
  };

  const handlePrevMonth = () => {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1));
  };

  const handlePrevYear = () => {
      setViewDate(new Date(viewDate.getFullYear() - 1, viewDate.getMonth(), 1));
  };

  const handleNextYear = () => {
      setViewDate(new Date(viewDate.getFullYear() + 1, viewDate.getMonth(), 1));
  };

  const handleMonthSelect = (monthIndex: number) => {
      setViewDate(new Date(viewDate.getFullYear(), monthIndex, 1));
      setIsMonthPickerOpen(false);
  };

  const isSelected = (d: Date) => {
    return d.getDate() === value.getDate() && 
           d.getMonth() === value.getMonth() && 
           d.getFullYear() === value.getFullYear();
  };

  const isToday = (d: Date) => {
    const now = new Date();
    return d.getDate() === now.getDate() && 
           d.getMonth() === now.getMonth() && 
           d.getFullYear() === now.getFullYear();
  };

  const handleDayClick = (date: Date) => {
    onChange(date);
  };

  const handleToday = () => {
    const now = new Date();
    onChange(now);
    setViewDate(now);
    setIsMonthPickerOpen(false);
  };

  const days = generateDays();

  return (
    <div className="w-[320px] bg-[#333333] rounded-3xl p-6 shadow-2xl font-sans text-white select-none animate-in zoom-in-95 duration-200 ring-1 ring-white/10 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 relative z-20">
        <button 
            onClick={() => setIsMonthPickerOpen(!isMonthPickerOpen)}
            className="flex items-center gap-1 text-lg font-bold tracking-wide hover:text-gray-300 transition-colors bg-white/5 px-3 py-1.5 rounded-lg border border-white/5 active:bg-white/10"
        >
          <span>{viewDate.getFullYear()}年</span>
          <span>{String(viewDate.getMonth() + 1).padStart(2, '0')}月</span>
          <span className={`material-symbols-outlined text-xl transition-transform duration-300 ${isMonthPickerOpen ? 'rotate-180' : ''}`}>arrow_drop_down</span>
        </button>
        
        <div className={`flex gap-1 transition-opacity duration-200 ${isMonthPickerOpen ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
            <button onClick={handlePrevMonth} className="size-9 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors text-gray-300 hover:text-white active:scale-95">
                <span className="material-symbols-outlined font-light text-2xl">chevron_left</span>
            </button>
            <button onClick={handleNextMonth} className="size-9 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors text-gray-300 hover:text-white active:scale-95">
                <span className="material-symbols-outlined font-light text-2xl">chevron_right</span>
            </button>
        </div>
      </div>

      <div className="relative overflow-hidden flex-1 min-h-[300px]">
          {/* Calendar Grid View */}
          <div className={`transition-all duration-300 absolute inset-0 flex flex-col ${isMonthPickerOpen ? 'opacity-0 scale-90 pointer-events-none' : 'opacity-100 scale-100'}`}>
            {/* Weekdays */}
            <div className="grid grid-cols-7 mb-2">
                {WEEKDAYS.map(day => (
                <div key={day} className="text-center text-xs text-[#888888] font-bold py-2">
                    {day}
                </div>
                ))}
            </div>

            {/* Days */}
            <div className="grid grid-cols-7 gap-y-2 gap-x-1 flex-1 content-start">
                {days.map((item, i) => {
                    const selected = isSelected(item.date);
                    const today = isToday(item.date);
                    return (
                    <button
                        key={i}
                        onClick={() => handleDayClick(item.date)}
                        className={`
                        size-9 flex items-center justify-center rounded-full text-sm font-medium transition-all mx-auto relative group
                        ${!item.currentMonth ? 'text-[#555555]' : 'text-white'}
                        ${selected 
                            ? 'bg-[#8AB4F8] text-[#333333] font-bold shadow-[0_0_15px_rgba(138,180,248,0.4)] scale-105' 
                            : today 
                                ? 'border-2 border-[#8AB4F8] text-[#8AB4F8]' 
                                : 'hover:bg-white/10'
                        }
                        `}
                    >
                        {item.day}
                        {today && !selected && (
                            <div className="absolute -bottom-1 size-1 rounded-full bg-[#8AB4F8]"></div>
                        )}
                    </button>
                    );
                })}
            </div>
          </div>

          {/* Month/Year Picker View */}
          <div className={`transition-all duration-300 absolute inset-0 flex flex-col bg-[#333333] z-10 ${!isMonthPickerOpen ? 'opacity-0 scale-110 pointer-events-none' : 'opacity-100 scale-100'}`}>
              {/* Year Selector */}
              <div className="flex items-center justify-between px-6 mb-4 py-2 bg-white/5 rounded-xl border border-white/5">
                  <button onClick={handlePrevYear} className="size-8 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors text-gray-300">
                     <span className="material-symbols-outlined">chevron_left</span>
                  </button>
                  <span className="text-xl font-black text-[#8AB4F8] tracking-widest">{viewDate.getFullYear()}</span>
                  <button onClick={handleNextYear} className="size-8 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors text-gray-300">
                     <span className="material-symbols-outlined">chevron_right</span>
                  </button>
              </div>
              
              {/* Months Grid */}
              <div className="grid grid-cols-3 gap-3 flex-1 content-center overflow-y-auto no-scrollbar pb-4">
                  {MONTHS.map((m, idx) => (
                      <button 
                        key={m}
                        onClick={() => handleMonthSelect(idx)}
                        className={`py-4 rounded-2xl text-sm font-bold transition-all border border-transparent ${
                            idx === viewDate.getMonth() 
                            ? 'bg-[#8AB4F8] text-[#333333] shadow-lg scale-105' 
                            : 'bg-[#444444] text-gray-300 hover:bg-[#555555] hover:border-white/10'
                        }`}
                      >
                          {m}
                      </button>
                  ))}
              </div>
          </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/10">
        <button 
            onClick={onClose}
            className="text-gray-400 text-xs font-bold hover:text-white transition-colors px-3 py-2 hover:bg-white/5 rounded-lg"
        >
            取消
        </button>
        <button 
            onClick={handleToday}
            className="text-[#8AB4F8] text-xs font-bold hover:text-[#AECBFA] transition-colors px-3 py-2 hover:bg-[#8AB4F8]/10 rounded-lg"
        >
            回到今天
        </button>
      </div>
    </div>
  );
};

export default CustomCalendar;