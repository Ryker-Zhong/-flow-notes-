import React, { useState } from 'react';
import { Note, ThemeConfig } from '../types';

interface DiaryEntryProps {
  onCancel: () => void;
  onSave: (note: Note) => void;
  theme: ThemeConfig;
}

const DiaryEntry: React.FC<DiaryEntryProps> = ({ onCancel, onSave, theme }) => {
  const [content, setContent] = useState("");
  const [title, setTitle] = useState(`${new Date().toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' })} 的随心记`);
  const [category, setCategory] = useState<Note['category']>("生活");

  const categories: Note['category'][] = ["生活", "工作", "灵感", "个人"];

  const handleSave = () => {
    if (!content.trim()) return;
    
    const newNote: Note = {
      id: Math.random().toString(36).substr(2, 9),
      title: title || "无题日记",
      content,
      category,
      type: 'DIARY',
      timestamp: new Date()
    };
    onSave(newNote);
  };

  return (
    <div className="h-full flex flex-col fade-in bg-[#FFFDF9]">
      <header className="flex-none px-6 pt-10 pb-4 flex items-center justify-between">
        <button onClick={onCancel} className="size-10 flex items-center justify-center bg-white rounded-full shadow-sm text-slate-400">
          <span className="material-symbols-outlined">close</span>
        </button>
        <h2 className="text-slate-900 text-lg font-bold">心流日记</h2>
        <div className="w-10"></div>
      </header>

      <main className="flex-1 px-8 pt-4 flex flex-col gap-6">
        <input 
          type="text" 
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="给这篇日记起个标题..."
          className="w-full text-2xl font-black text-slate-900 border-none bg-transparent p-0 focus:ring-0 placeholder:text-slate-200"
        />
        
        <div className="flex-1 relative">
          <textarea 
            autoFocus
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="此刻你在想什么？让思绪自然流淌..."
            className="w-full h-full text-lg leading-relaxed text-slate-700 border-none bg-transparent p-0 focus:ring-0 placeholder:text-slate-200 resize-none"
          />
        </div>
      </main>

      <div className="flex-none p-8 space-y-8 bg-gradient-to-t from-white to-transparent">
        <div>
          <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-4 px-1">选择分类</label>
          <div className="flex gap-3">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-5 py-2.5 rounded-2xl text-xs font-bold transition-all ${
                  category === cat 
                  ? `bg-slate-900 text-white shadow-lg shadow-slate-900/20 scale-105` 
                  : 'bg-white text-slate-400 border border-slate-100'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <button 
          onClick={handleSave}
          disabled={!content.trim()}
          className={`w-full h-16 ${theme.colors.primaryBg} ${theme.colors.primaryBgHover} disabled:opacity-20 text-white font-black text-sm uppercase tracking-[0.2em] rounded-2xl shadow-2xl ${theme.colors.shadow} flex items-center justify-center gap-3 active:scale-[0.98] transition-all`}
        >
          保存这篇日记
          <span className="material-symbols-outlined">auto_awesome</span>
        </button>
      </div>
    </div>
  );
};

export default DiaryEntry;