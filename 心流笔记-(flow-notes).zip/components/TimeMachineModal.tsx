import React from 'react';
import { Note } from '../types';

interface TimeMachineModalProps {
  matchedNote: Note;
  onClose: () => void;
}

const TimeMachineModal: React.FC<TimeMachineModalProps> = ({ matchedNote, onClose }) => {
  const timeDiff = () => {
    const now = new Date();
    const past = new Date(matchedNote.timestamp);
    const years = now.getFullYear() - past.getFullYear();
    const months = now.getMonth() - past.getMonth() + (12 * years);
    const days = Math.floor((now.getTime() - past.getTime()) / (1000 * 3600 * 24));

    if (years > 0 && past.getDate() === now.getDate() && past.getMonth() === now.getMonth()) {
      return `${years} 年前的今天`;
    }
    if (years > 0) return `${years} 年前`;
    if (months > 0) return `${months} 个月前`;
    if (days > 0) return `${days} 天前`;
    return "之前的某一天";
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-xl animate-in fade-in duration-700" 
        onClick={onClose}
      ></div>

      {/* Main Card */}
      <div className="relative w-full max-w-sm bg-gradient-to-br from-[#1e1b4b] to-[#312e81] rounded-[3rem] p-1 shadow-2xl overflow-hidden animate-in zoom-in-95 slide-in-from-bottom-8 duration-700 border border-indigo-400/30">
        
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20 animate-[spin_60s_linear_infinite]"></div>
          <div className="absolute top-10 right-10 size-32 bg-indigo-500/30 rounded-full blur-[60px] animate-pulse"></div>
          <div className="absolute bottom-10 left-10 size-40 bg-fuchsia-500/20 rounded-full blur-[60px] animate-pulse" style={{animationDelay: '1s'}}></div>
        </div>

        <div className="relative bg-[#0f172a]/80 backdrop-blur-sm rounded-[2.8rem] p-8 text-center h-full flex flex-col items-center">
          
          {/* Header Icon */}
          <div className="size-16 rounded-full bg-gradient-to-br from-indigo-400 to-fuchsia-400 p-[2px] mb-6 shadow-lg shadow-indigo-500/40 animate-bounce">
            <div className="w-full h-full rounded-full bg-[#1e1b4b] flex items-center justify-center">
              <span className="material-symbols-outlined text-3xl text-indigo-200">history_edu</span>
            </div>
          </div>

          <h3 className="text-indigo-200 text-sm font-bold tracking-[0.3em] uppercase mb-1">心情时光机</h3>
          <h2 className="text-white text-2xl font-black font-display tracking-wide mb-6">
            与过去的自己重逢
          </h2>

          <div className="w-full bg-white/5 rounded-3xl p-6 border border-white/10 text-left mb-8 relative group">
            <div className="absolute top-0 right-0 px-4 py-2 bg-indigo-500 rounded-bl-2xl rounded-tr-2xl text-[10px] font-bold text-white shadow-lg">
              {timeDiff()}
            </div>
            
            <p className="text-indigo-200/60 text-xs font-bold mb-2 flex items-center gap-2">
              <span className="material-symbols-outlined text-sm">calendar_month</span>
              {formatDate(new Date(matchedNote.timestamp))}
            </p>
            
            <h4 className="text-white text-lg font-bold mb-3 line-clamp-1">{matchedNote.title}</h4>
            <p className="text-slate-300 text-sm leading-relaxed line-clamp-4 italic font-serif opacity-90">
              “{matchedNote.content}”
            </p>

            <div className="mt-4 pt-4 border-t border-white/5 flex items-center gap-2">
                <span className="text-[10px] text-indigo-300 bg-indigo-900/50 px-2 py-1 rounded-md border border-indigo-500/30">
                    当时心情
                </span>
                {/* Simplified mood display based on category or implicit mood if available */}
                <span className="text-xs text-white">
                   {matchedNote.category}
                </span>
            </div>
          </div>

          <button 
            onClick={onClose}
            className="w-full py-4 bg-white text-indigo-900 rounded-2xl font-black text-sm tracking-widest uppercase hover:bg-indigo-50 active:scale-95 transition-all shadow-xl shadow-indigo-900/50"
          >
            收下这份回忆
          </button>
        </div>
      </div>
    </div>
  );
};

export default TimeMachineModal;
