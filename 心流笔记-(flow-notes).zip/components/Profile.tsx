import React, { useState, useRef, useMemo } from 'react';
import { Note, UserProfile, AppTheme, ThemeConfig, THEME_CONFIG } from '../types';
import CustomCalendar from './CustomCalendar';

interface ProfileProps {
  notes: Note[];
  unlockedBadgeCount: number;
  userProfile: UserProfile;
  onUpdateProfile: (profile: UserProfile) => void;
  theme: ThemeConfig;
  onNavigateToNotifications: () => void;
  onNavigateToPrivacy: () => void; // New prop
}

const PRESET_AVATARS = [
  "https://images.unsplash.com/photo-1494022299300-899b96e49893?auto=format&fit=crop&w=200&q=80",
  "https://images.unsplash.com/photo-1513002749550-c59d786b8e6c?auto=format&fit=crop&w=200&q=80",
  "https://images.unsplash.com/photo-1459411552884-841db9b3cc2a?auto=format&fit=crop&w=200&q=80",
  "https://images.unsplash.com/photo-1579546929518-9e396f3cc809?auto=format&fit=crop&w=200&q=80",
  "https://images.unsplash.com/photo-1470790376778-a9fcd484f043?auto=format&fit=crop&w=200&q=80",
  "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=200&q=80",
];

const NICKNAME_SUGGESTIONS = ["晚风", "星笺", "拾光者", "云边", "半岛", "微光", "清梦", "岛屿", "山月"];

const getAvatarStyle = (shape: UserProfile['avatarShape'], theme: ThemeConfig) => {
    switch (shape) {
        case 'square':
            return {
                container: `rounded-[2.5rem] border-4 ${theme.colors.border}`,
                img: 'rounded-[2.2rem]'
            };
        case 'stamp':
            return {
                container: `rounded-[18px] border-[3px] border-dashed ${theme.colors.border} bg-white p-1.5`,
                img: 'rounded-[12px]'
            };
        case 'blob':
            return {
                container: `rounded-[60%_40%_30%_70%/60%_30%_70%_40%] border-4 ${theme.colors.border} rotate-3 transition-transform`,
                img: 'rounded-[60%_40%_30%_70%/60%_30%_70%_40%]'
            };
        case 'circle':
        default:
            return {
                container: `rounded-full border-4 ${theme.colors.border}`,
                img: 'rounded-full'
            };
    }
};

const Profile: React.FC<ProfileProps> = ({ notes, unlockedBadgeCount, userProfile, onUpdateProfile, theme, onNavigateToNotifications, onNavigateToPrivacy }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const [tempProfile, setTempProfile] = useState<UserProfile>(userProfile);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isDateModalOpen, setIsDateModalOpen] = useState(false);
  const [tempJoinDate, setTempJoinDate] = useState<Date>(new Date());

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTempProfile(prev => ({ ...prev, avatar: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const generateNickname = () => {
    const randomName = NICKNAME_SUGGESTIONS[Math.floor(Math.random() * NICKNAME_SUGGESTIONS.length)];
    setTempProfile(prev => ({ ...prev, nickname: randomName }));
  };

  const saveProfile = () => {
    onUpdateProfile(tempProfile);
    setIsEditing(false);
  };

  const openEditModal = () => {
      setTempProfile(userProfile);
      setIsEditing(true);
  };

  const openDateModal = () => {
    setTempJoinDate(new Date(userProfile.joinDate || new Date()));
    setIsDateModalOpen(true);
  };

  const saveDate = (newDate: Date) => {
    onUpdateProfile({ ...userProfile, joinDate: newDate });
    setIsDateModalOpen(false);
  };

  const daysJoined = useMemo(() => {
    const start = new Date(userProfile.joinDate || new Date());
    const now = new Date();
    const startDay = new Date(start.getFullYear(), start.getMonth(), start.getDate());
    const nowDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    const diff = nowDay.getTime() - startDay.getTime();
    return Math.floor(diff / (1000 * 60 * 60 * 24)) + 1;
  }, [userProfile.joinDate]);

  const stats = useMemo(() => {
    const textDiaries = notes.filter(n => n.type === 'DIARY' || (n.content && !n.audioData)).length;
    const audioDiaries = notes.filter(n => n.type === 'ECHO' || n.audioData).length;
    const fragments = notes.filter(n => n.category === '生活').length; 
    const streak = 7; 
    return { textDiaries, audioDiaries, fragments, streak };
  }, [notes]);

  const styles = getAvatarStyle(userProfile.avatarShape, theme);

  // --- DETAIL VIEW: Personal Profile Stats ---
  if (showStats) {
    return (
      <div className="h-full flex flex-col no-scrollbar overflow-y-auto fade-in bg-[#FFFDF9] relative">
        <header className="px-6 pt-12 pb-6 flex items-center gap-4 sticky top-0 bg-[#FFFDF9]/90 backdrop-blur-md z-10">
          <button 
            onClick={() => setShowStats(false)} 
            className="size-10 flex items-center justify-center bg-white rounded-full shadow-sm text-slate-400 border border-slate-100 active:scale-95 transition-transform"
          >
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
          <h2 className="text-slate-900 text-xl font-bold">个人资料</h2>
        </header>

        <div className="px-6 pb-24 space-y-6">
          {/* 1. Companionship Duration (Editable) */}
          <div className="w-full bg-white rounded-[2rem] p-6 shadow-sm border border-slate-100 flex items-center justify-between">
             <div className="flex flex-col">
                <span className="text-xs text-slate-400 font-bold mb-1">相伴时长</span>
                <p className="text-slate-800 font-bold text-lg">
                  与时光相伴的第 <span className={`text-2xl font-black mx-1 ${theme.colors.primary}`}>{daysJoined}</span> 天
                </p>
             </div>
             
             <button 
                onClick={openDateModal}
                className={`size-12 rounded-2xl flex items-center justify-center transition-colors active:scale-90 shadow-sm ${theme.colors.secondaryBg} ${theme.colors.secondary} hover:${theme.colors.iconBg}`}
                title="修改开始时间"
             >
               <span className="material-symbols-outlined text-2xl">calendar_month</span>
             </button>
          </div>

          {/* 2. Annual Mood Keyword */}
          <div className={`w-full rounded-[2rem] p-6 border relative overflow-hidden ${theme.colors.border} ${theme.colors.secondaryBg}`}>
             <div className="relative z-10 flex justify-between items-center">
                <div>
                   <p className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-2 text-slate-500">年度心情关键词</p>
                   <p className={`text-2xl font-black tracking-widest ${theme.colors.primary}`}>
                     今年的你，关键词是「平和」
                   </p>
                </div>
                <span className={`material-symbols-outlined text-4xl opacity-80 ${theme.colors.primary}`}>spa</span>
             </div>
             <div className="absolute -right-6 -bottom-6 size-32 bg-white/40 rounded-full blur-2xl"></div>
          </div>

          {/* 3. Record Achievements */}
          <div className="w-full bg-white rounded-[2rem] p-2 shadow-sm border border-slate-100">
              <p className="text-xs text-slate-400 font-bold px-4 pt-4 pb-2">记录总成果</p>
              <div className="space-y-1">
                <div className="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-50 transition-colors">
                    <span className="text-2xl">✍️</span>
                    <p className="text-slate-700 text-sm font-bold">
                      写下了 <span className={`text-lg mx-1 ${theme.colors.secondary}`}>{stats.textDiaries}</span> 篇生活絮语
                    </p>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-50 transition-colors">
                    <span className="text-2xl">🎙️</span>
                    <p className="text-slate-700 text-sm font-bold">
                      收藏了 <span className="text-teal-500 text-lg mx-1">{stats.audioDiaries}</span> 段时光留声
                    </p>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-50 transition-colors">
                    <span className="text-2xl">📸</span>
                    <p className="text-slate-700 text-sm font-bold">
                      定格了 <span className="text-amber-500 text-lg mx-1">{stats.fragments}</span> 张生活碎片
                    </p>
                </div>
              </div>
          </div>

          {/* 4. Streak Achievement */}
          <div className={`w-full rounded-[2rem] p-6 border relative bg-gradient-to-br from-slate-50 to-white ${theme.colors.border}`}>
             <div className="flex justify-between items-start">
                <div>
                   <p className={`text-[10px] font-black uppercase tracking-widest mb-1 ${theme.colors.secondary}`}>连续打卡成就</p>
                   <p className="text-slate-900 font-black text-lg">
                     正在进行 <span className="text-2xl mx-1">{stats.streak}</span> 天连续记录
                   </p>
                </div>
                <div className="bg-white p-2 rounded-xl shadow-sm">
                   <span className={`material-symbols-outlined text-2xl ${theme.colors.primary}`}>forest</span>
                </div>
             </div>
             
             {stats.streak >= 30 ? (
                <div className="mt-4 flex items-center gap-2 bg-white/60 p-2 rounded-xl border border-white/50 backdrop-blur-sm">
                   <span className="material-symbols-outlined text-amber-500">military_tech</span>
                   <span className="text-xs font-bold text-slate-600">已点亮 “时光守护者” 勋章</span>
                </div>
             ) : (
                <div className={`mt-4 h-1.5 w-full rounded-full overflow-hidden ${theme.colors.secondaryBg}`}>
                   <div className={`h-full rounded-full ${theme.colors.primaryBg}`} style={{ width: `${(stats.streak / 30) * 100}%` }}></div>
                </div>
             )}
          </div>
        </div>

        {/* Custom Calendar Modal */}
        {isDateModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md transition-opacity" onClick={() => setIsDateModalOpen(false)}></div>
            <div className="relative z-10">
               <CustomCalendar 
                  value={tempJoinDate}
                  onChange={(date) => saveDate(date)}
                  onClose={() => setIsDateModalOpen(false)}
               />
            </div>
          </div>
        )}
      </div>
    );
  }

  // --- MAIN VIEW ---
  return (
    <div className="h-full flex flex-col no-scrollbar overflow-y-auto fade-in relative">
      <header className="px-6 pt-12 pb-6 flex items-center justify-center">
        <h2 className="text-slate-900 text-xl font-bold tracking-wide">个人中心</h2>
      </header>

      <div className="px-6 py-4">
        {/* Profile Card Summary */}
        <div className="bg-white/60 backdrop-blur-md rounded-[2.5rem] p-8 border border-white shadow-xl flex flex-col items-center text-center relative overflow-hidden group transition-all">
          <div className="relative mb-5">
            <div 
                onClick={openEditModal}
                className={`size-28 bg-white shadow-inner overflow-hidden transition-all duration-500 cursor-pointer relative group/avatar ${styles.container}`}
            >
              <img src={userProfile.avatar} className={`w-full h-full object-cover ${styles.img}`} alt="User Avatar" />
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover/avatar:opacity-100 transition-opacity">
                 <span className="material-symbols-outlined text-white font-bold">photo_camera</span>
              </div>
            </div>

            {userProfile.avatarShape === 'stamp' && (
                <div className={`absolute -bottom-2 -right-2 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm rotate-[-5deg] pointer-events-none ${theme.colors.primaryBg}`}>
                    POST
                </div>
            )}
            {userProfile.avatarShape === 'blob' && (
                <div className={`absolute top-0 -right-2 bg-white/80 backdrop-blur-sm size-6 rounded-full flex items-center justify-center shadow-sm pointer-events-none`}>
                    <span className={`material-symbols-outlined text-xs ${theme.colors.secondary}`}>cloud</span>
                </div>
            )}
          </div>

          <h3 className="text-slate-900 text-2xl font-bold font-serif italic tracking-wide">{userProfile.nickname}</h3>
          
           <div className="relative mt-3 mb-8 max-w-[80%]">
             <span className={`absolute -top-2 -left-2 text-3xl font-serif leading-none ${theme.colors.secondary} opacity-40`}>“</span>
             <p className="text-slate-500 text-sm italic font-serif leading-relaxed px-2">
               {userProfile.bio || "写下一句你的生活序章"}
             </p>
             <span className={`absolute -bottom-4 -right-2 text-3xl font-serif leading-none ${theme.colors.secondary} opacity-40`}>”</span>
          </div>

          <div className="grid grid-cols-3 gap-8 w-full border-t border-slate-100 pt-6">
            <div><p className={`text-lg font-bold ${theme.colors.primary}`}>{notes.length}</p><p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">累计日记</p></div>
            <div className="border-x border-slate-100"><p className={`text-lg font-bold ${theme.colors.primary}`}>{stats.streak}</p><p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">连续天数</p></div>
            <div><p className={`text-lg font-bold ${theme.colors.primary}`}>{unlockedBadgeCount}</p><p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">获得勋章</p></div>
          </div>
        </div>
      </div>

      <div className="px-6 py-6 space-y-4">
        <h4 className="text-slate-400 text-xs font-bold uppercase tracking-widest px-2 pt-4">通用</h4>
        <div className="bg-white/40 backdrop-blur-sm rounded-3xl overflow-hidden border border-white">
          <MenuLink icon="person" label="个人资料" subLabel="查看详细数据档案" theme={theme} onClick={() => setShowStats(true)} />
          <MenuLink icon="notifications" label="消息通知" subLabel="勿扰模式与提醒" theme={theme} onClick={onNavigateToNotifications} />
          <MenuLink icon="shield_with_heart" label="隐私与安全" subLabel="数据加密与备份" theme={theme} onClick={onNavigateToPrivacy} last />
        </div>

        <div className="pt-6 pb-24 text-center">
          <button className={`text-sm font-bold flex items-center justify-center gap-2 mx-auto px-4 py-2 rounded-xl transition-colors ${theme.colors.primary} hover:${theme.colors.secondaryBg}`}>
            <span className="material-symbols-outlined text-sm">logout</span>退出登录
          </button>
          <p className="text-slate-300 text-[10px] mt-4 tracking-widest uppercase">Version 2.3.0 (Pure Flow)</p>
        </div>
      </div>

      {isEditing && (
        <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center">
          <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={() => setIsEditing(false)}></div>
          <div className="relative bg-white w-full max-w-md h-[90vh] sm:h-auto sm:rounded-[2.5rem] rounded-t-[2.5rem] shadow-2xl flex flex-col animate-in slide-in-from-bottom duration-300">
            <div className="flex-none px-6 pt-6 pb-4 flex items-center justify-between border-b border-slate-100">
                <button onClick={() => setIsEditing(false)} className="text-slate-400 hover:text-slate-600 font-bold text-sm">取消</button>
                <h3 className="text-slate-900 font-bold text-lg">编辑资料</h3>
                <button onClick={saveProfile} className={`font-bold text-sm hover:opacity-80 ${theme.colors.primary}`}>保存</button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-8 no-scrollbar pb-20">
                {/* Avatar Section */}
                <div className="flex flex-col items-center">
                    <div 
                        className={`size-32 mb-6 relative group cursor-pointer overflow-hidden transition-all duration-300 bg-white shadow-inner ${getAvatarStyle(tempProfile.avatarShape, THEME_CONFIG[tempProfile.theme || 'default']).container}`} 
                        onClick={() => fileInputRef.current?.click()}
                    >
                        <img src={tempProfile.avatar} className={`w-full h-full object-cover ${getAvatarStyle(tempProfile.avatarShape, THEME_CONFIG[tempProfile.theme || 'default']).img}`} />
                        <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="material-symbols-outlined text-white">photo_camera</span>
                        </div>
                    </div>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
                    
                    {/* Visual Shape Toggle */}
                    <div className="w-full">
                        <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-3 text-center">头像形状</p>
                        <div className="flex justify-center gap-4">
                            {(['circle', 'square', 'stamp', 'blob'] as const).map(shape => (
                                <button 
                                key={shape}
                                onClick={() => setTempProfile(p => ({...p, avatarShape: shape}))}
                                className={`size-12 rounded-xl border-2 flex items-center justify-center transition-all ${
                                    tempProfile.avatarShape === shape 
                                    ? `${theme.colors.border} ${theme.colors.secondaryBg}` 
                                    : 'border-slate-200 hover:border-slate-300'
                                }`}
                                >
                                    <div className="size-6 bg-slate-400 rounded-md opacity-30"></div>
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Theme Selector */}
                    <div className="w-full mt-2">
                        <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-3 text-center">主题风格</p>
                        <div className="flex justify-center gap-4">
                            {Object.values(THEME_CONFIG).map(t => (
                                <button 
                                    key={t.id}
                                    onClick={() => setTempProfile(p => ({...p, theme: t.id}))}
                                    className={`relative size-12 rounded-full bg-gradient-to-br ${t.gradient} flex items-center justify-center transition-all duration-300 ${
                                        (tempProfile.theme === t.id || (!tempProfile.theme && t.id === 'default'))
                                        ? 'scale-110 shadow-lg ring-2 ring-slate-200 ring-offset-2' 
                                        : 'opacity-70 hover:opacity-100 hover:scale-105'
                                    }`}
                                    title={t.name}
                                >
                                    {(tempProfile.theme === t.id || (!tempProfile.theme && t.id === 'default')) && (
                                        <div className="size-3 bg-white rounded-full shadow-sm animate-in zoom-in duration-300"></div>
                                    )}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Presets */}
                    <div className="mt-6 w-full">
                        <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-3 text-center">文艺插画</p>
                        <div className="flex gap-3 overflow-x-auto pb-4 px-2 no-scrollbar justify-center">
                            {PRESET_AVATARS.map((url, i) => (
                                <button 
                                    key={i} 
                                    onClick={() => setTempProfile(p => ({...p, avatar: url}))}
                                    className={`size-12 shrink-0 rounded-xl overflow-hidden border-2 transition-all ${tempProfile.avatar === url ? `${theme.colors.border} scale-110` : 'border-transparent opacity-70 hover:opacity-100'}`}
                                >
                                    <img src={url} className="w-full h-full object-cover" />
                                </button>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Nickname Section */}
                <div>
                    <div className="flex justify-between items-center mb-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">昵称</label>
                        <button onClick={generateNickname} className={`text-[10px] font-bold flex items-center gap-1 px-2 py-0.5 rounded-md transition-colors ${theme.colors.secondary} hover:${theme.colors.secondaryBg}`}>
                            <span className="material-symbols-outlined text-xs">auto_awesome</span> 随机生成
                        </button>
                    </div>
                    <input 
                        type="text" 
                        value={tempProfile.nickname}
                        onChange={e => setTempProfile(p => ({...p, nickname: e.target.value}))}
                        className={`w-full bg-slate-50 border-none rounded-2xl px-4 py-3 text-slate-800 font-serif font-bold text-lg focus:ring-2 ${theme.colors.ring}`}
                    />
                </div>

                {/* Bio Section */}
                <div>
                     <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">个性签名</label>
                     <div className="relative">
                        <textarea 
                            value={tempProfile.bio}
                            onChange={e => setTempProfile(p => ({...p, bio: e.target.value}))}
                            placeholder="写下一句你的生活序章..."
                            rows={3}
                            className={`w-full bg-slate-50 border-none rounded-2xl px-4 py-3 text-slate-600 font-serif italic focus:ring-2 ${theme.colors.ring} resize-none`}
                        />
                        <div className="absolute bottom-3 right-3 flex gap-1">
                             {["一半烟火", "收藏时光"].map(tag => (
                                 <button key={tag} onClick={() => setTempProfile(p => ({...p, bio: tag}))} className={`text-[9px] bg-white border border-slate-100 px-2 py-1 rounded-md text-slate-400 transition-colors hover:${theme.colors.secondary} hover:${theme.colors.border}`}>
                                     {tag}
                                 </button>
                             ))}
                        </div>
                     </div>
                </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const MenuLink: React.FC<{ icon: string; label: string; subLabel?: string; last?: boolean; onClick?: () => void; theme: ThemeConfig }> = ({ icon, label, subLabel, last, onClick, theme }) => (
  <button onClick={onClick} className={`w-full flex items-center gap-4 p-4 hover:bg-white/60 transition-colors text-left ${!last ? 'border-b border-white/50' : ''}`}>
    <div className={`size-10 rounded-2xl bg-white flex items-center justify-center shadow-sm ${theme.colors.secondary}`}><span className="material-symbols-outlined">{icon}</span></div>
    <div className="flex-1"><p className="text-slate-800 text-sm font-bold">{label}</p>{subLabel && <p className="text-slate-400 text-[10px]">{subLabel}</p>}</div>
    <span className="material-symbols-outlined text-slate-300">chevron_right</span>
  </button>
);

export default Profile;