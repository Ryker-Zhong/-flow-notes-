export enum AppView {
  WELCOME = 'WELCOME',
  DASHBOARD = 'DASHBOARD',
  DIARY_ENTRY = 'DIARY_ENTRY',
  FUTURE_LETTER_ENTRY = 'FUTURE_LETTER_ENTRY',
  ECHO_ENTRY = 'ECHO_ENTRY',
  INSPIRATION_ENTRY = 'INSPIRATION_ENTRY',
  DIARY = 'DIARY',
  REVIEW = 'REVIEW',
  SETTINGS = 'SETTINGS',
  NOTIFICATIONS = 'NOTIFICATIONS',
  PRIVACY = 'PRIVACY' // 新增视图
}

export enum ReflectionType {
  DAILY = 'DAILY',
  EVENT = 'EVENT'
}

export interface ReflectionQuestion {
  id: string;
  text: string;
  icon: string;
  placeholder: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  audioData?: string;
  duration?: number;
  category: '工作' | '生活' | '灵感' | '个人' | '时空信笺' | '空谷留音';
  type?: 'DIARY' | 'REFLECTION_DAILY' | 'REFLECTION_EVENT' | 'FUTURE_LETTER' | 'ECHO';
  timestamp: Date;
  unlockDate?: Date; 
  mood?: number; 
}

export interface Badge {
    id: number;
    icon: string;
    name: string;
    desc: string;
    unlocked: boolean;
    color: string;
    ring: string;
}

export type AppTheme = 'default' | 'ocean' | 'forest' | 'lavender';

export interface UserProfile {
    id?: string; // For Supabase user ID
    nickname: string;
    avatar: string;
    bio: string;
    avatarShape: 'circle' | 'square' | 'stamp' | 'blob';
    joinDate: Date;
    theme?: AppTheme;
}

// 移动 Reminder 接口到这里，以便全局使用
export interface Reminder {
  id: number;
  text: string;
  time: string;
  completed: boolean;
  category: string;
  isDailyEssential?: boolean;
  dueTimestamp?: number;
  notifiedStages: ('2h' | '1h' | '30m')[];
}

export interface ThemeConfig {
    id: AppTheme;
    name: string;
    colors: {
        primary: string;      // e.g., text-rose-500
        primaryBg: string;    // e.g., bg-rose-500
        primaryBgHover: string; // e.g., hover:bg-rose-600
        secondary: string;    // e.g., text-rose-400
        secondaryBg: string;  // e.g., bg-rose-50
        border: string;       // e.g., border-rose-100
        ring: string;         // e.g., focus:ring-rose-100 (needs full class for tailwind)
        ringColor: string;    // e.g., ring-rose-50
        iconBg: string;       // e.g., bg-rose-100
        shadow: string;       // e.g., shadow-rose-500/20
    };
    gradient: string;
}

export const THEME_CONFIG: Record<AppTheme, ThemeConfig> = {
    default: {
        id: 'default',
        name: '晨曦粉',
        colors: {
            primary: 'text-rose-500',
            primaryBg: 'bg-rose-500',
            primaryBgHover: 'hover:bg-rose-600',
            secondary: 'text-rose-400',
            secondaryBg: 'bg-rose-50',
            border: 'border-rose-200',
            ring: 'focus:ring-rose-100',
            ringColor: 'ring-rose-50',
            iconBg: 'bg-rose-100',
            shadow: 'shadow-rose-500/20'
        },
        gradient: 'from-pink-50 via-rose-50 to-amber-50'
    },
    ocean: {
        id: 'ocean',
        name: '海盐蓝',
        colors: {
            primary: 'text-blue-500',
            primaryBg: 'bg-blue-500',
            primaryBgHover: 'hover:bg-blue-600',
            secondary: 'text-blue-400',
            secondaryBg: 'bg-blue-50',
            border: 'border-blue-200',
            ring: 'focus:ring-blue-100',
            ringColor: 'ring-blue-50',
            iconBg: 'bg-blue-100',
            shadow: 'shadow-blue-500/20'
        },
        gradient: 'from-slate-50 via-blue-50 to-cyan-50'
    },
    forest: {
        id: 'forest',
        name: '薄荷绿',
        colors: {
            primary: 'text-emerald-500',
            primaryBg: 'bg-emerald-500',
            primaryBgHover: 'hover:bg-emerald-600',
            secondary: 'text-emerald-400',
            secondaryBg: 'bg-emerald-50',
            border: 'border-emerald-200',
            ring: 'focus:ring-emerald-100',
            ringColor: 'ring-emerald-50',
            iconBg: 'bg-emerald-100',
            shadow: 'shadow-emerald-500/20'
        },
        gradient: 'from-emerald-50 via-teal-50 to-lime-50'
    },
    lavender: {
        id: 'lavender',
        name: '罗兰紫',
        colors: {
            primary: 'text-violet-500',
            primaryBg: 'bg-violet-500',
            primaryBgHover: 'hover:bg-violet-600',
            secondary: 'text-violet-400',
            secondaryBg: 'bg-violet-50',
            border: 'border-violet-200',
            ring: 'focus:ring-violet-100',
            ringColor: 'ring-violet-50',
            iconBg: 'bg-violet-100',
            shadow: 'shadow-violet-500/20'
        },
        gradient: 'from-violet-50 via-purple-50 to-fuchsia-50'
    }
};