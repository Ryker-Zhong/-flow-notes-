import { createClient } from '@supabase/supabase-js';

// 硬编码 Supabase 凭据以确保它们在此纯浏览器环境中
// 被正确配置。
const supabaseUrl = 'https://smcbmjuhywcdniuncizi.supabase.co';

// 这是您的公开匿名密钥 (public anon key)，在客户端应用中是安全的。
// "Failed to fetch" 错误表明存在连接问题，很可能是凭据不正确导致的。
// 密钥现已更新为您提供的值。
// 如果问题仍然存在，请在您的 Supabase 项目的 API 设置中仔细核对
// 这里的 URL 和匿名密钥是否完全正确。
const supabaseAnonKey = 'sb_publishable_Q5OsmFqRrArt6bYvWKMRMQ_CUYJL1yN';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);