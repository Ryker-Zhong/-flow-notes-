import React, { useState, useEffect, useMemo } from 'react';
import { AppView, Note, Badge, UserProfile, AppTheme, THEME_CONFIG, Reminder } from './types';
import Welcome from './components/Welcome';
import Dashboard from './components/Dashboard';
import DiaryEntry from './components/DiaryEntry';
import FutureLetterEntry from './components/FutureLetterEntry'; 
import EchoValleyEntry from './components/EchoValleyEntry';
import InspirationEntry from './components/InspirationEntry';
import BottomNav from './components/BottomNav';
import Profile from './components/Profile';
import Review from './components/Review';
import DiaryView from './components/DiaryView';
import TimeMachineModal from './components/TimeMachineModal';
import TimeMachineLoader from './components/TimeMachineLoader';
import NotificationsView from './components/NotificationsView';
import PrivacyView from './components/PrivacyView';
import { supabase } from './services/supabaseClient';
import { Session, AuthError } from '@supabase/supabase-js';

const INITIAL_NOTES: Note[] = [
  {
    id: '1',
    title: '深夜漫谈：关于未来的思考',
    content: '今日在公园散步时，突然对职业路径有了新的感悟。有时候慢下来，反而能看得更远。',
    category: '个人',
    type: 'DIARY',
    timestamp: new Date(Date.now() - 7200000),
  },
  {
     id: 'demo-past',
     title: '去年的今天',
     content: '去年的这个时候，我正在为那个项目焦头烂额。现在回想起来，那也是一段宝贵的经历。',
     category: '工作',
     type: 'DIARY',
     timestamp: new Date(new Date().setFullYear(new Date().getFullYear() - 1)),
     mood: 2
  }
];

const INITIAL_PROFILE: UserProfile = {
    nickname: "拾光者",
    avatar: "https://images.unsplash.com/photo-1513002749550-c59d786b8e6c?auto=format&fit=crop&w=200&q=80", // Cloud
    bio: "把日子写成诗，收藏时光的碎片。",
    avatarShape: 'circle',
    joinDate: new Date('2023-11-15'),
    theme: 'default'
};

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.WELCOME);
  const [notes, setNotes] = useState<Note[]>(INITIAL_NOTES);
  const [isTypeSelectorOpen, setIsTypeSelectorOpen] = useState(false);
  const [session, setSession] = useState<Session | null>(null);
  
  // User Profile State
  const [userProfile, setUserProfile] = useState<UserProfile>(INITIAL_PROFILE);
  const isLoggedIn = useMemo(() => !!session, [session]);
  
  // Mood State
  const [todayMood, setTodayMood] = useState<number | null>(null);

  // Supabase Auth Listener
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Fetch or Create User Profile when session changes
  useEffect(() => {
    if (session?.user) {
      const fetchProfile = async () => {
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();

        if (data) {
          setUserProfile({
            ...data,
            joinDate: new Date(data.joinDate) // Ensure date is a Date object
          });
        } else if (error) {
          // Profile doesn't exist, create it
          const newUserProfile: UserProfile = {
            id: session.user.id,
            nickname: session.user.user_metadata.user_name || '新来的拾光者',
            avatar: session.user.user_metadata.avatar_url || INITIAL_PROFILE.avatar,
            bio: INITIAL_PROFILE.bio,
            avatarShape: 'circle',
            joinDate: new Date(),
            theme: 'default',
          };
          
          const { error: insertError } = await supabase.from('profiles').insert(newUserProfile);
          if (!insertError) {
            setUserProfile(newUserProfile);
          } else {
            console.error("Error creating profile:", insertError.message);
          }
        }
      };
      fetchProfile();
    } else {
        // When logged out, revert to initial/guest profile
        setUserProfile(INITIAL_PROFILE);
    }
  }, [session]);

  const handleLogin = async (email: string, password: string): Promise<AuthError | null> => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) {
      console.error("Login Error:", error.message);
    }
    return error;
  };

  const handleSignUp = async (email: string, password: string): Promise<AuthError | { message: string } | null> => {
      const { data, error } = await supabase.auth.signUp({
          email,
          password,
      });
      if (error) {
        console.error("Sign Up Error:", error.message);
        return error;
      }
      if (data.user && data.session === null) {
        // User signed up, but needs to confirm email.
        return { message: "注册成功！请检查您的邮箱以完成验证。" };
      }
      return null;
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setCurrentView(AppView.SETTINGS); // Navigate to settings page after logout
  };
  
  const handleUpdateProfile = async (updatedProfile: UserProfile) => {
    if (!session?.user) return;

    const updates = {
      ...updatedProfile,
      id: session.user.id,
      updated_at: new Date().toISOString(),
    };
    
    // Omit session/user specific data not in the 'profiles' table schema
    const { id, joinDate, ...profileData } = updates;
    const profileToUpdate = { id, ...profileData, joinDate: new Date(joinDate).toISOString() };

    const { error } = await supabase.from('profiles').upsert(profileToUpdate);
    if (error) {
      console.error('Error updating profile:', error.message);
    } else {
      // Optimistically update local state
      setUserProfile(updatedProfile);
    }
  };


  // --- Reminders State & Logic (Lifted from Dashboard) ---
  const [reminders, setReminders] = useState<Reminder[]>(() => {
    const getTodayTimestamp = (timeStr: string): number | undefined => {
        const parts = timeStr.split(':');
        if (parts.length === 2) {
            const d = new Date();
            d.setHours(parseInt(parts[0]), parseInt(parts[1]), 0, 0);
            return d.getTime();
        }
        return undefined;
    };

    const getTomorrowTimestamp = (timeStr: string): number | undefined => {
        const parts = timeStr.split(':');
        if (parts.length === 2) {
            const d = new Date();
            d.setDate(d.getDate() + 1);
            d.setHours(parseInt(parts[0]), parseInt(parts[1]), 0, 0);
            return d.getTime();
        }
        return undefined;
    };
    
    return [
      { 
          id: 1, 
          text: "准备 Q4 季度市场营销会议 PPT", 
          time: "14:00", 
          completed: false, 
          category: "工作", 
          isDailyEssential: true,
          dueTimestamp: getTodayTimestamp("14:00"),
          notifiedStages: []
      },
      { 
          id: 2, 
          text: "给妈妈挑选生日礼物", 
          time: "17:30", 
          completed: true, 
          category: "生活",
          dueTimestamp: getTodayTimestamp("17:30"),
          notifiedStages: []
      },
      { 
          id: 3, 
          text: "完成今天的冥想与复盘", 
          time: "21:00", 
          completed: false, 
          category: "个人", 
          isDailyEssential: true,
          dueTimestamp: getTodayTimestamp("21:00"),
          notifiedStages: []
      },
      { 
          id: 4, 
          text: "预约牙医检查", 
          time: "明天 10:00", 
          completed: false, 
          category: "琐事",
          dueTimestamp: getTomorrowTimestamp("10:00"),
          notifiedStages: []
      }
    ];
  });

  // Request Notification Permission on Mount
  useEffect(() => {
    if ('Notification' in window && Notification.permission !== 'granted') {
      Notification.requestPermission();
    }
  }, []);

  // Reminder Check Loop (Every 10 seconds)
  useEffect(() => {
    const checkReminders = () => {
        const now = Date.now();
        let hasUpdates = false;

        const updatedReminders = reminders.map(r => {
            if (r.completed || !r.dueTimestamp) return r;

            const diffMs = r.dueTimestamp - now;
            const diffMinutes = Math.floor(diffMs / 60000); 
            
            let stageToAdd: '2h' | '1h' | '30m' | null = null;

            if (diffMinutes <= 120 && diffMinutes > 115 && !r.notifiedStages.includes('2h')) {
                stageToAdd = '2h';
            }
            else if (diffMinutes <= 60 && diffMinutes > 55 && !r.notifiedStages.includes('1h')) {
                stageToAdd = '1h';
            }
            else if (diffMinutes <= 30 && diffMinutes > 25 && !r.notifiedStages.includes('30m')) {
                stageToAdd = '30m';
            }

            if (stageToAdd) {
                if ('Notification' in window && Notification.permission === 'granted') {
                    const timeText = stageToAdd === '30m' ? '30分钟' : stageToAdd === '1h' ? '1小时' : '2小时';
                    new Notification(`⏳ 任务即将开始: ${r.text}`, {
                        body: `还有 ${timeText} 到期 (${r.time})`,
                        icon: userProfile?.avatar || '/favicon.ico',
                        silent: false
                    });
                }
                hasUpdates = true;
                return { ...r, notifiedStages: [...r.notifiedStages, stageToAdd] };
            }
            return r;
        });

        if (hasUpdates) {
            setReminders(updatedReminders);
        }
    };

    const intervalId = setInterval(checkReminders, 10000); 
    return () => clearInterval(intervalId);
  }, [reminders, userProfile]);

  const toggleReminder = (id: number) => {
    setReminders(prev => prev.map(r => r.id === id ? { ...r, completed: !r.completed } : r));
  };

  const removeReminder = (id: number) => {
    setReminders(prev => prev.filter(r => r.id !== id));
  };

  const addReminder = (text: string, date: Date, timeStr: string, category: string, isDaily: boolean) => {
    const getTimestamp = (d: Date, t: string): number | undefined => {
      const parts = t.split(':');
      if (parts.length === 2) {
          const newDate = new Date(d);
          newDate.setHours(parseInt(parts[0]), parseInt(parts[1]), 0, 0);
          return newDate.getTime();
      }
      return undefined;
    };
    
    const timestamp = getTimestamp(date, timeStr);

    const isSameDay = (d1: Date, d2: Date) => {
        return d1.getFullYear() === d2.getFullYear() &&
               d1.getMonth() === d2.getMonth() &&
               d1.getDate() === d2.getDate();
    };

    const isTomorrow = (d: Date) => {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        return isSameDay(d, tomorrow);
    }
    
    let displayTime = timeStr;
    const today = new Date();

    if (!isSameDay(date, today)) {
        if (isTomorrow(date)) {
            displayTime = `明天 ${timeStr}`;
        } else {
            displayTime = `${date.getMonth() + 1}月${date.getDate()}日 ${timeStr}`;
        }
    }

    const newItem: Reminder = {
      id: Date.now(),
      text: text,
      time: displayTime,
      completed: false,
      category: category,
      isDailyEssential: isDaily,
      dueTimestamp: timestamp,
      notifiedStages: []
    };
    setReminders(prev => [newItem, ...prev]);
  };
  // --------------------------------------------------

  const currentTheme = useMemo(() => {
      return THEME_CONFIG[userProfile.theme || 'default'];
  }, [userProfile.theme]);

  // Initialize today's mood from notes
  useEffect(() => {
    const now = new Date();
    const todayNote = notes.find(n => 
      n.mood !== undefined && 
      n.timestamp.getDate() === now.getDate() &&
      n.timestamp.getMonth() === now.getMonth() &&
      n.timestamp.getFullYear() === now.getFullYear()
    );
    if (todayNote && todayNote.mood !== undefined) {
      setTodayMood(todayNote.mood);
    }
  }, [notes]);

  // Generate Stable Past Data for Review
  const stablePastData = useMemo(() => {
    const weeklyPast = Array.from({ length: 6 }, () => Math.floor(Math.random() * 5));
    const monthlyPast = [0, 0, 0, 0, 0];
    for(let i=0; i<29; i++) monthlyPast[Math.floor(Math.random() * 5)]++;
    return { weeklyPast, monthlyPast };
  }, []);

  // Calculate Badges
  const badges: Badge[] = useMemo(() => {
    const totalNotes = notes.length;
    const nightNotes = notes.filter(n => {
        const h = new Date(n.timestamp).getHours();
        return h >= 22 || h < 4;
    }).length;
    
    // Calculate happy days using past data + today's mood
    const currentMonthlyCounts = [...stablePastData.monthlyPast];
    if (todayMood !== null) {
        currentMonthlyCounts[todayMood]++;
    }
    const happyDays = currentMonthlyCounts[3] + currentMonthlyCounts[4];

    const earlyBird = notes.some(n => {
         const h = new Date(n.timestamp).getHours();
         return h >= 5 && h < 9;
    });
    const weekend = notes.some(n => {
         const d = new Date(n.timestamp).getDay();
         return d === 0 || d === 6;
    });
    const longNote = notes.some(n => n.content && n.content.length > 200);
    const hasFutureLetter = notes.some(n => n.type === 'FUTURE_LETTER');
    const hasEcho = notes.some(n => n.type === 'ECHO');
    const inspirationCount = notes.filter(n => n.category === '灵感').length;

    return [
        { id: 1, icon: 'edit_note', name: '初识日记', desc: '累计记录 1 篇日记', unlocked: totalNotes >= 1, color: 'text-blue-500 from-blue-50 to-blue-100', ring: 'ring-blue-200' },
        { id: 2, icon: 'auto_awesome', name: '小太阳', desc: '累计 5 天心情不错', unlocked: happyDays >= 5, color: 'text-amber-500 from-amber-50 to-amber-100', ring: 'ring-amber-200' },
        { id: 3, icon: 'dark_mode', name: '深夜哲思', desc: '深夜记录 1 次', unlocked: nightNotes >= 1, color: 'text-indigo-500 from-indigo-50 to-indigo-100', ring: 'ring-indigo-200' },
        { id: 4, icon: 'calendar_month', name: '周更达人', desc: '累计记录 7 篇日记', unlocked: totalNotes >= 7, color: 'text-emerald-500 from-emerald-50 to-emerald-100', ring: 'ring-emerald-200' },
        { id: 5, icon: 'diamond', name: '百篇达成', desc: '累计记录 100 篇', unlocked: totalNotes >= 100, color: 'text-rose-500 from-rose-50 to-rose-100', ring: 'ring-rose-200' },
        { id: 6, icon: 'psychology', name: '自我洞察', desc: '完成 3 次深度复盘', unlocked: false, color: 'text-purple-500 from-purple-50 to-purple-100', ring: 'ring-purple-200' },
        { id: 7, icon: 'wb_twilight', name: '早起鸟', desc: '在清晨 5-9 点记录一次', unlocked: earlyBird, color: 'text-orange-400 from-orange-50 to-orange-100', ring: 'ring-orange-200' },
        { id: 8, icon: 'weekend', name: '周末时光', desc: '在周末记录生活', unlocked: weekend, color: 'text-lime-500 from-lime-50 to-lime-100', ring: 'ring-lime-200' },
        { id: 9, icon: 'history_edu', name: '笔耕不辍', desc: '写下一篇超过 200 字的日记', unlocked: longNote, color: 'text-stone-500 from-stone-50 to-stone-100', ring: 'ring-stone-200' },
        { id: 10, icon: 'send_time_extension', name: '时光信使', desc: '寄出一封给未来的信', unlocked: hasFutureLetter, color: 'text-cyan-500 from-cyan-50 to-cyan-100', ring: 'ring-cyan-200' },
        { id: 11, icon: 'graphic_eq', name: '听见心声', desc: '录制一段语音日记', unlocked: hasEcho, color: 'text-teal-500 from-teal-50 to-teal-100', ring: 'ring-teal-200' },
        { id: 12, icon: 'lightbulb', name: '灵感捕手', desc: '记录 3 次灵感时刻', unlocked: inspirationCount >= 3, color: 'text-yellow-500 from-yellow-50 to-yellow-100', ring: 'ring-yellow-200' },
    ];
  }, [notes, todayMood, stablePastData]);

  const unlockedBadgeCount = badges.filter(b => b.unlocked).length;

  const [isTimeTraveling, setIsTimeTraveling] = useState(false);
  const [showTimeMachine, setShowTimeMachine] = useState(false);
  const [timeMachineNote, setTimeMachineNote] = useState<Note | null>(null);

  const triggerTimeMachine = (currentNote: Note | null, currentMoodIndex: number | null) => {
    const now = new Date();
    const cYear = now.getFullYear();
    const cMonth = now.getMonth();
    const cDate = now.getDate();
    
    let matched: Note | undefined;
    const candidateNotes = notes.filter(n => n.id !== currentNote?.id);

    matched = candidateNotes.find(n => 
        n.timestamp.getFullYear() === cYear - 1 &&
        n.timestamp.getMonth() === cMonth &&
        n.timestamp.getDate() === cDate
    );

    if (!matched) {
        const onThisDay = candidateNotes.filter(n => 
            n.timestamp.getFullYear() !== cYear &&
            n.timestamp.getMonth() === cMonth &&
            n.timestamp.getDate() === cDate
        );

        if (onThisDay.length > 0) {
            const specialEvent = onThisDay.find(n => 
                n.title.includes('生日') || 
                n.title.includes('纪念日') || 
                n.title.includes('周年')
            );
            matched = specialEvent || onThisDay.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())[0];
        }
    }

    if (matched) {
        setTimeMachineNote(matched);
        setIsTimeTraveling(true);
        setTimeout(() => {
            setIsTimeTraveling(false);
            setShowTimeMachine(true);
        }, 2000);
    }
  };

  const handleCompleteDiary = (newNote: Note) => {
    setNotes(prev => [newNote, ...prev]);
    setCurrentView(AppView.DIARY);
  };

  const handleMoodLogged = (moodIndex: number) => {
      setTodayMood(moodIndex);
      triggerTimeMachine(null, moodIndex);
  };

  const renderView = () => {
    switch (currentView) {
      case AppView.WELCOME:
        return <Welcome onStart={() => setCurrentView(AppView.DASHBOARD)} />;
      case AppView.DASHBOARD:
        return (
          <Dashboard 
            notes={notes} 
            progress={33} 
            onStartReflection={() => setIsTypeSelectorOpen(true)} 
            onProfileClick={() => setCurrentView(AppView.SETTINGS)}
            userProfile={userProfile}
            theme={currentTheme}
            reminders={reminders}
            onToggleReminder={toggleReminder}
            onRemoveReminder={removeReminder}
            onAddReminder={addReminder}
          />
        );
      case AppView.DIARY_ENTRY:
        return (
          <DiaryEntry 
            onCancel={() => setCurrentView(AppView.DASHBOARD)}
            onSave={handleCompleteDiary}
            theme={currentTheme}
          />
        );
      case AppView.FUTURE_LETTER_ENTRY:
        return (
          <FutureLetterEntry 
            onCancel={() => setCurrentView(AppView.DASHBOARD)}
            onSave={handleCompleteDiary}
          />
        );
      case AppView.ECHO_ENTRY:
        return (
           <EchoValleyEntry 
             onCancel={() => setCurrentView(AppView.DASHBOARD)}
             onSave={handleCompleteDiary}
           />
        );
      case AppView.INSPIRATION_ENTRY:
        return (
          <InspirationEntry
            onCancel={() => setCurrentView(AppView.DASHBOARD)}
            onSave={handleCompleteDiary}
            theme={currentTheme}
          />
        );
      case AppView.DIARY:
        return <DiaryView notes={notes} theme={currentTheme} />; 
      case AppView.REVIEW:
        return (
          <Review 
            notes={notes} 
            onMoodLogged={handleMoodLogged} 
            confirmedMood={todayMood}
            stablePastData={stablePastData}
            badges={badges}
            theme={currentTheme}
          />
        );
      case AppView.SETTINGS:
        return (
            <Profile 
                notes={notes} 
                unlockedBadgeCount={unlockedBadgeCount} 
                userProfile={userProfile}
                onUpdateProfile={handleUpdateProfile}
                theme={currentTheme}
                isLoggedIn={isLoggedIn}
                onLogin={handleLogin}
                onSignUp={handleSignUp}
                onLogout={handleLogout}
                onNavigateToNotifications={() => setCurrentView(AppView.NOTIFICATIONS)}
                onNavigateToPrivacy={() => setCurrentView(AppView.PRIVACY)}
            />
        );
      case AppView.NOTIFICATIONS:
        return (
           <NotificationsView 
              reminders={reminders}
              theme={currentTheme}
              onBack={() => setCurrentView(AppView.SETTINGS)}
              onToggleReminder={toggleReminder}
           />
        );
      case AppView.PRIVACY:
        return (
           <PrivacyView 
              theme={currentTheme}
              onBack={() => setCurrentView(AppView.SETTINGS)}
           />
        );
      default:
        return <Dashboard 
          notes={notes} 
          progress={33} 
          onStartReflection={() => setIsTypeSelectorOpen(true)} 
          onProfileClick={() => setCurrentView(AppView.SETTINGS)} 
          userProfile={userProfile} 
          theme={currentTheme}
          reminders={reminders}
          onToggleReminder={toggleReminder}
          onRemoveReminder={removeReminder}
          onAddReminder={addReminder}
        />;
    }
  };

  return (
    <div className={`relative flex flex-col h-screen w-full max-w-md mx-auto overflow-hidden bg-gradient-to-br ${currentTheme.gradient} shadow-2xl transition-colors duration-1000 ease-in-out`}>
      <main className="flex-1 overflow-hidden relative">
        {renderView()}
      </main>
      
      {currentView !== AppView.WELCOME && 
       currentView !== AppView.DIARY_ENTRY && 
       currentView !== AppView.FUTURE_LETTER_ENTRY && 
       currentView !== AppView.ECHO_ENTRY &&
       currentView !== AppView.INSPIRATION_ENTRY &&
       currentView !== AppView.NOTIFICATIONS && 
       currentView !== AppView.PRIVACY && (
        <BottomNav 
          activeView={currentView} 
          onViewChange={setCurrentView} 
          onAddClick={() => setIsTypeSelectorOpen(true)}
          theme={currentTheme}
        />
      )}

      {isTimeTraveling && <TimeMachineLoader />}

      {showTimeMachine && timeMachineNote && !isTimeTraveling && (
          <TimeMachineModal 
              matchedNote={timeMachineNote} 
              onClose={() => setShowTimeMachine(false)} 
          />
      )}

      {isTypeSelectorOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
          <div 
            className="fixed inset-0 bg-slate-900/30 backdrop-blur-xl animate-in fade-in duration-700" 
            onClick={() => setIsTypeSelectorOpen(false)}
          ></div>
          <div className="relative w-full max-w-sm bg-white/95 rounded-[3.5rem] p-8 pb-12 animate-in zoom-in-95 duration-500 shadow-2xl border border-white/50 overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-32 bg-gradient-to-b ${currentTheme.colors.secondaryBg}/30 to-transparent pointer-events-none`}></div>
            
            <header className="mb-8 text-center relative z-10 pt-4 stagger-in-1">
              <div className={`size-16 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-sm animate-breathe ${currentTheme.colors.secondaryBg} ${currentTheme.colors.secondary}`}>
                <span className="material-symbols-outlined text-4xl font-light">auto_awesome</span>
              </div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tight">记录新篇章</h3>
            </header>

            <div className="space-y-4 relative z-10">
              <button 
                onClick={() => {
                  setIsTypeSelectorOpen(false);
                  setCurrentView(AppView.DIARY_ENTRY);
                }}
                className="w-full flex items-center gap-4 p-6 rounded-[2.2rem] bg-gradient-to-br from-blue-50/50 to-blue-100/40 hover:from-blue-100 hover:to-blue-200 transition-all duration-500 border border-blue-50 shadow-xl shadow-blue-100/10 group active:scale-[0.96] stagger-in-2"
              >
                <div className="size-14 rounded-2xl bg-white/80 text-blue-500 shadow-sm flex items-center justify-center group-hover:scale-110 transition-transform">
                  <span className="material-symbols-outlined text-3xl font-bold">water_drop</span>
                </div>
                <div className="text-left">
                  <h4 className="text-lg font-black text-blue-600">心流日记</h4>
                  <p className="text-blue-400 text-[10px] font-medium leading-tight">随心书写，不设局限</p>
                </div>
              </button>

              <button 
                onClick={() => {
                  setIsTypeSelectorOpen(false);
                  setCurrentView(AppView.FUTURE_LETTER_ENTRY);
                }}
                className="w-full flex items-center gap-4 p-6 rounded-[2.2rem] bg-gradient-to-br from-orange-50/50 to-orange-100/40 hover:from-orange-100 hover:to-orange-200 transition-all duration-500 shadow-xl shadow-orange-100/10 group active:scale-[0.96] border border-orange-50 stagger-in-3"
              >
                <div className="size-14 rounded-2xl bg-white/80 text-orange-300 shadow-sm flex items-center justify-center group-hover:scale-110 transition-transform">
                  <span className="material-symbols-outlined text-3xl font-bold">auto_awesome</span>
                </div>
                <div className="text-left">
                  <h4 className="text-lg font-black text-orange-400">时空信笺</h4>
                  <p className="text-orange-200 text-[10px] font-bold leading-tight uppercase tracking-widest">给未来的自己寄信</p>
                </div>
              </button>

              <button 
                onClick={() => {
                  setIsTypeSelectorOpen(false);
                  setCurrentView(AppView.ECHO_ENTRY);
                }}
                className="w-full flex items-center gap-4 p-6 rounded-[2.2rem] bg-gradient-to-br from-teal-50/50 to-teal-100/40 hover:from-teal-100 hover:to-teal-200 transition-all duration-500 shadow-xl shadow-teal-100/10 group active:scale-[0.96] border border-teal-50 stagger-in-4"
              >
                <div className="size-14 rounded-2xl bg-white/80 text-teal-400 shadow-sm flex items-center justify-center group-hover:scale-110 transition-transform">
                  <span className="material-symbols-outlined text-3xl font-bold">graphic_eq</span>
                </div>
                <div className="text-left">
                  <h4 className="text-lg font-black text-teal-600">空谷留音</h4>
                  <p className="text-teal-400 text-[10px] font-bold leading-tight uppercase tracking-widest">待来日风起，会听见当时的回响</p>
                </div>
              </button>
              
              <button 
                onClick={() => {
                  setIsTypeSelectorOpen(false);
                  setCurrentView(AppView.INSPIRATION_ENTRY);
                }}
                className="w-full flex items-center gap-4 p-6 rounded-[2.2rem] bg-gradient-to-br from-amber-50/50 to-amber-100/40 hover:from-amber-100 hover:to-amber-200 transition-all duration-500 shadow-xl shadow-amber-100/10 group active:scale-[0.96] border border-amber-50 stagger-in-4"
              >
                <div className="size-14 rounded-2xl bg-white/80 text-amber-400 shadow-sm flex items-center justify-center group-hover:scale-110 transition-transform">
                  <span className="material-symbols-outlined text-3xl font-bold">lightbulb</span>
                </div>
                <div className="text-left">
                  <h4 className="text-lg font-black text-amber-600">灵感小集</h4>
                  <p className="text-amber-400 text-[10px] font-bold leading-tight uppercase tracking-widest">快速捕捉灵感的火花</p>
                </div>
              </button>

            </div>

            <div className="mt-10 text-center stagger-in-4">
              <button 
                onClick={() => setIsTypeSelectorOpen(false)}
                className={`text-slate-300 font-bold text-xs uppercase tracking-[0.4em] hover:${currentTheme.colors.primary} transition-colors py-2 active:scale-95`}
              >
                暂时放弃
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;